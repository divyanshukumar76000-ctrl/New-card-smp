package com.cardsmp;

import com.cardsmp.commands.CardsmpCommand;
import com.cardsmp.inventory.gui.GUIListener;
import com.cardsmp.inventory.gui.GUIManager;
import com.cardsmp.listeners.*;
import com.cardsmp.managers.ActiveCardManager;
import com.cardsmp.managers.CooldownManager;
import org.bukkit.plugin.PluginManager;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.HashSet;
import java.util.Objects;
import java.util.UUID;

public class CardsmpPlugin extends JavaPlugin {

    private CooldownManager cooldownManager;
    private ActiveCardManager activeCardManager;
    private GUIManager guiManager;

    @Override
    public void onEnable() {
        this.cooldownManager = new CooldownManager();
        this.activeCardManager = new ActiveCardManager();
        this.guiManager = new GUIManager();

        registerListeners();
        registerCommands();

        getLogger().info("[Cardsmp] Plugin Enabled");
    }

    @Override
    public void onDisable() {
        // Cleanup all active cards in strict order
        for (UUID playerUUID : new HashSet<>(activeCardManager.getActivePlayers())) {
            activeCardManager.cleanupPlayer(playerUUID);
        }
        activeCardManager.clearAll();

        getLogger().info("[Cardsmp] Plugin Disabled");
    }

    private void registerListeners() {
        PluginManager pm = getServer().getPluginManager();
        pm.registerEvents(new CardUseListener(this), this);
        pm.registerEvents(new CardSecurityListener(this), this);
        pm.registerEvents(new GUIListener(guiManager), this);
        pm.registerEvents(new CleanupListener(this), this);
        pm.registerEvents(new TargetListener(activeCardManager), this);
    }

    private void registerCommands() {
        Objects.requireNonNull(getCommand("cardsmp")).setExecutor(new CardsmpCommand(this));
    }

    public CooldownManager getCooldownManager() {
        return cooldownManager;
    }

    public ActiveCardManager getActiveCardManager() {
        return activeCardManager;
    }

    public GUIManager getGuiManager() {
        return guiManager;
    }
}