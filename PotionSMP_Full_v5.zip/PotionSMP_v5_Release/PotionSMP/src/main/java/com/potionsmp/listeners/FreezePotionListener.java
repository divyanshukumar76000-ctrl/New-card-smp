package com.potionsmp.listeners;

import com.potionsmp.PotionSMP;
import com.potionsmp.utils.PotionUtils;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.scheduler.BukkitRunnable;

/**
 * Handles the Freeze Potion's PASSIVE ability only.
 * The ACTIVE ability (Arctic Prison) is triggered via the /rspark command
 * (see PotionCommand), so it can be bound to a key with a client-side
 * bind-command mod.
 */
public class FreezePotionListener implements Listener {

    private final PotionSMP plugin;

    public FreezePotionListener(PotionSMP plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onHit(EntityDamageByEntityEvent event) {
        if (!(event.getDamager() instanceof Player player)) return;
        if (!(event.getEntity() instanceof LivingEntity target)) return;

        if (!plugin.getPlayerPotionManager().isFreezeActive(player.getUniqueId())) return;

        int hits = plugin.getHitCounterManager().incrementFreeze(player.getUniqueId());
        int threshold = plugin.getConfig().getInt("freeze-potion.passive-hits", 10);

        if (hits >= threshold) {
            plugin.getHitCounterManager().resetFreeze(player.getUniqueId());
            int freezeDur = plugin.getConfig().getInt("freeze-potion.passive-freeze-duration", 40);

            target.damage(2.0, player);
            plugin.getFrozenPlayerManager().freezeEntity(target, freezeDur);

            target.getWorld().spawnParticle(Particle.SNOWFLAKE, target.getLocation().add(0, 1, 0), 20, 0.5, 0.5, 0.5, 0.05);
            target.getWorld().playSound(target.getLocation(), Sound.BLOCK_GLASS_BREAK, 1f, 1.5f);
            player.sendMessage(PotionUtils.colorize("&b❄ Passive freeze triggered!"));
        } else {
            target.getWorld().spawnParticle(Particle.SNOWFLAKE, target.getLocation().add(0, 1, 0), 3, 0.2, 0.2, 0.2, 0.01);
        }
    }

    /**
     * Activates Arctic Prison for the given player. Called from /rspark.
     */
    public static ActivationResult activate(PotionSMP plugin, Player player) {
        if (!plugin.getPlayerPotionManager().isFreezeActive(player.getUniqueId())) {
            return ActivationResult.NO_POTION;
        }

        if (plugin.getCooldownManager().isOnCooldown(player.getUniqueId(), PotionUtils.FREEZE)) {
            return ActivationResult.ON_COOLDOWN;
        }

        int radius = plugin.getConfig().getInt("freeze-potion.active-radius", 10);
        int freezeDur = plugin.getConfig().getInt("freeze-potion.active-freeze-duration", 60);
        int cooldown = plugin.getConfig().getInt("freeze-potion.active-cooldown", 45);

        plugin.getCooldownManager().setCooldown(player.getUniqueId(), PotionUtils.FREEZE, cooldown);
        player.sendMessage(PotionUtils.msg("freeze-active"));

        Location center = player.getLocation();

        center.getWorld().spawnParticle(Particle.SNOWFLAKE, center.clone().add(0, 1, 0), 150, radius / 2.0, 1.5, radius / 2.0, 0.05);
        center.getWorld().spawnParticle(Particle.ITEM_SNOWBALL, center.clone().add(0, 1, 0), 80, radius / 2.0, 1, radius / 2.0, 0.2);
        center.getWorld().playSound(center, Sound.ENTITY_GUARDIAN_ELDER_CURSE, 1.5f, 0.5f);
        center.getWorld().playSound(center, Sound.BLOCK_POWDER_SNOW_STEP, 1f, 0.5f);

        for (Entity e : center.getWorld().getNearbyEntities(center, radius, radius, radius)) {
            if (e instanceof LivingEntity le && !e.getUniqueId().equals(player.getUniqueId())) {
                plugin.getFrozenPlayerManager().freezeEntity(le, freezeDur);

                if (le instanceof Player frozen) {
                    frozen.sendMessage(PotionUtils.colorize("&b❄ You are frozen by &f" + player.getName() + "&b's Arctic Prison!"));
                }
            }
        }

        new BukkitRunnable() {
            int ticks = 0;
            double angle = 0;

            @Override
            public void run() {
                if (ticks >= freezeDur) { cancel(); return; }
                for (int i = 0; i < 8; i++) {
                    double a = Math.toRadians(angle + (i * 45));
                    double x = Math.cos(a) * (radius * 0.5);
                    double z = Math.sin(a) * (radius * 0.5);
                    center.getWorld().spawnParticle(Particle.SNOWFLAKE, center.clone().add(x, 1, z), 1, 0, 0, 0, 0);
                }
                angle += 15;
                ticks++;
            }
        }.runTaskTimer(plugin, 0L, 1L);

        return ActivationResult.SUCCESS;
    }

    public enum ActivationResult {
        SUCCESS, NO_POTION, ON_COOLDOWN
    }
}
