package com.potionsmp.managers;

import com.potionsmp.PotionSMP;
import org.bukkit.Bukkit;
import org.bukkit.boss.BarColor;
import org.bukkit.boss.BarStyle;
import org.bukkit.boss.BossBar;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class BossBarManager {

    private final PotionSMP plugin;
    private final Map<UUID, BossBar>     bars    = new HashMap<>();
    private final Map<UUID, BukkitTask>  tickers = new HashMap<>();

    public BossBarManager(PotionSMP plugin) { this.plugin = plugin; }

    public void show(Player player, String title, BarColor color, int durationSeconds) {
        UUID uid = player.getUniqueId();
        remove(uid);

        BossBar bar = Bukkit.createBossBar(title, color, BarStyle.SEGMENTED_10);
        bar.setProgress(1.0);
        bar.addPlayer(player);
        bars.put(uid, bar);

        long totalTicks = durationSeconds * 20L;
        long[] elapsed  = {0};

        BukkitTask ticker = plugin.getServer().getScheduler().runTaskTimer(plugin, () -> {
            elapsed[0]++;
            double progress = 1.0 - ((double) elapsed[0] / totalTicks);
            if (progress <= 0 || !player.isOnline()) { remove(uid); return; }
            bar.setProgress(Math.max(0, progress));
        }, 1L, 1L);

        tickers.put(uid, ticker);
    }

    public void remove(UUID uid) {
        BukkitTask t = tickers.remove(uid);
        if (t != null) { try { t.cancel(); } catch (Exception ignored) {} }
        BossBar bar = bars.remove(uid);
        if (bar != null) bar.removeAll();
    }

    public void removeAll() {
        tickers.forEach((u, t) -> { try { t.cancel(); } catch (Exception ignored) {} });
        tickers.clear();
        bars.forEach((u, b) -> b.removeAll());
        bars.clear();
    }
}
