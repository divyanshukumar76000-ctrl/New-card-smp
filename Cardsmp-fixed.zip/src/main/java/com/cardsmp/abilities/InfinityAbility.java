package com.cardsmp.abilities;

import com.cardsmp.CardsmpPlugin;
import com.cardsmp.cards.CardType;
import com.cardsmp.managers.ActiveCardManager;
import com.cryptomorin.xseries.XSound;
import org.bukkit.Color;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.entity.*;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;

import java.util.UUID;

public class InfinityAbility {

    // 30s duration = 300 iterations at 2-tick interval
    private static final int DURATION_ITERATIONS = 300;

    public static void activate(Player owner, CardsmpPlugin plugin) {
        UUID ownerUUID = owner.getUniqueId();
        ActiveCardManager manager = plugin.getActiveCardManager();

        manager.setActiveCard(ownerUUID, CardType.INFINITY);
        manager.setCombatTriggered(ownerUUID, false);

        // Spawn dragon above owner
        Location spawnLoc = owner.getLocation().clone().add(0, 15, 0);
        EnderDragon dragon = (EnderDragon) owner.getWorld().spawnEntity(spawnLoc, EntityType.ENDER_DRAGON);
        dragon.setAI(false);  // Passive until combat trigger
        dragon.setPersistent(true);
        manager.addEntity(ownerUUID, dragon);

        XSound.matchXSound("ENTITY_ENDER_DRAGON_GROWL").ifPresent(s ->
            owner.getWorld().playSound(owner.getLocation(), s.get(), 3f, 1f));

        // Activation FX: reverse portal ring
        Location activeLoc = owner.getLocation().clone().add(0, 1, 0);
        for (int i = 0; i < 24; i++) {
            double angle = 2 * Math.PI * i / 24;
            Location ring = activeLoc.clone().add(Math.cos(angle) * 3, 0, Math.sin(angle) * 3);
            activeLoc.getWorld().spawnParticle(Particle.REVERSE_PORTAL, ring, 3, 0.1, 0.1, 0.1, 0.05);
        }
        activeLoc.getWorld().spawnParticle(Particle.DRAGON_BREATH, activeLoc, 40, 1.5, 1.5, 1.5, 0.05);

        int[] ticks = {0};

        BukkitTask task = new BukkitRunnable() {
            @Override
            public void run() {
                if (dragon.isDead() || !owner.isOnline() || !manager.hasActiveCard(ownerUUID)) {
                    cancel();
                    return;
                }

                ticks[0]++;
                boolean combat = manager.isCombatTriggered(ownerUUID);

                Location dragonLoc = dragon.getLocation();

                // Dragon breath particle aura every run
                if (ticks[0] % 3 == 0) {
                    dragonLoc.getWorld().spawnParticle(Particle.DRAGON_BREATH,
                        dragonLoc, 8, 1.5, 1.5, 1.5, 0.04);
                }

                if (!combat) {
                    // Passive: hover near owner
                    Location ownerAbove = owner.getLocation().clone().add(0, 15, 0);
                    if (dragonLoc.distanceSquared(ownerAbove) > 625) {
                        dragon.teleport(ownerAbove);
                    }
                } else {
                    // Enable AI so dragon attacks naturally
                    if (!dragon.hasAI()) {
                        dragon.setAI(true);
                        XSound.matchXSound("ENTITY_ENDER_DRAGON_FLAP").ifPresent(s ->
                            owner.getWorld().playSound(owner.getLocation(), s.get(), 2f, 1f));
                    }

                    // Roar shockwave every 50 iterations (5s)
                    if (ticks[0] % 50 == 0) {
                        doShockwave(owner, ownerUUID, dragonLoc, manager, plugin);
                    }
                }

                if (ticks[0] >= DURATION_ITERATIONS) {
                    manager.cleanupPlayer(ownerUUID);
                    cancel();
                }
            }
        }.runTaskTimer(plugin, 0L, 2L);

        manager.addTask(ownerUUID, task);
    }

    private static void doShockwave(Player owner, UUID ownerUUID, Location dragonLoc,
                                    ActiveCardManager manager, CardsmpPlugin plugin) {
        // Reverse portal ring
        for (int i = 0; i < 32; i++) {
            double angle = 2 * Math.PI * i / 32;
            Location ring = dragonLoc.clone().add(Math.cos(angle) * 4, 0.5, Math.sin(angle) * 4);
            ring.getWorld().spawnParticle(Particle.DRAGON_BREATH, ring, 4, 0.1, 0.1, 0.1, 0.03);
            ring.getWorld().spawnParticle(Particle.REVERSE_PORTAL, ring, 2, 0.1, 0.1, 0.1, 0.05);
        }

        // Purple dust wave
        dragonLoc.getWorld().spawnParticle(Particle.DUST,
            dragonLoc, 30, 2, 1, 2, 0,
            new Particle.DustOptions(Color.fromRGB(80, 0, 160), 2.0f));

        // Roar sound
        XSound.matchXSound("ENTITY_ENDER_DRAGON_GROWL").ifPresent(s ->
            dragonLoc.getWorld().playSound(dragonLoc, s.get(), 3f, 0.7f));

        // Shockwave damage to nearby enemy players — owner FULLY IMMUNE (ABSOLUTE RULE)
        for (Entity entity : dragonLoc.getWorld().getNearbyEntities(dragonLoc, 8, 8, 8)) {
            if (entity instanceof Player victim) {
                if (victim.getUniqueId().equals(ownerUUID)) continue;
                victim.damage(8.0); // 4 hearts shockwave
            }
        }
    }
}