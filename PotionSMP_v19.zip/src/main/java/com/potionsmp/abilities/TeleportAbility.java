package com.potionsmp.abilities;

import com.potionsmp.PotionSMP;
import com.potionsmp.utils.PotionType;
import com.potionsmp.utils.PotionUtils;
import org.bukkit.*;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

import java.util.*;

/**
 * §3 Teleport Potion – Shadow Hunter
 *
 * PASSIVE:
 *   - Infinite Invisibility while equipped
 *   - Faint shadow-leak particles (Squid Ink + purple dust, very sparse)
 *     so the player can be barely detected
 *
 * ACTIVE – Shadow Teleport (90 s CD):
 *   1. Nearest / looked-at player is auto-targeted
 *   2. 5-second countdown with dark-portal particles gathering inward
 *   3. Instant teleport to target (ignores walls)
 *   4. On arrival:
 *        - Enderman teleport flash + purple-black shockwave ring
 *        - Nausea + Blindness I on target (3 s)
 *        - Screen-distortion title on target
 *   5. Ability ends immediately – no lingering duration
 *   Invisibility is re-applied 2 ticks after teleport.
 */
public class TeleportAbility implements Ability {

    private final Set<UUID>          inCountdown = new HashSet<>();

    @Override
    public PotionType type() { return PotionType.TELEPORT; }

    // ── Equip / Unequip ───────────────────────────────────────────────────

    @Override
    public void onEquip(PotionSMP plugin, Player player) {
        applyInvisibility(player);
        startShadowTrail(plugin, player);
        player.sendMessage(PotionUtils.colorize("&5🌀 Shadow Cloak active — you are invisible."));
    }

    @Override
    public void onUnequip(PotionSMP plugin, Player player) {
        player.removePotionEffect(PotionEffectType.INVISIBILITY);
        plugin.getParticleManager().cancelAura(player.getUniqueId());
        inCountdown.remove(player.getUniqueId());
    }

    private void applyInvisibility(Player player) {
        player.addPotionEffect(new PotionEffect(
            PotionEffectType.INVISIBILITY, Integer.MAX_VALUE, 0, false, false));
    }

    // ── Passive: shadow trail ─────────────────────────────────────────────

    private void startShadowTrail(PotionSMP plugin, Player player) {
        plugin.getParticleManager().cancelAura(player.getUniqueId());
        new BukkitRunnable() {
            double angle = 0;
            @Override
            public void run() {
                if (!player.isOnline() ||
                    !plugin.getSlotManager().hasEquipped(player.getUniqueId(), PotionType.TELEPORT)) {
                    cancel(); return;
                }
                if (!player.hasPotionEffect(PotionEffectType.INVISIBILITY)) applyInvisibility(player);

                angle += 0.3;
                Location loc = player.getLocation().add(0, 0.1, 0);
                if (Math.random() < 0.33) {
                    double r = 0.4 + Math.random() * 0.3;
                    loc.getWorld().spawnParticle(Particle.SQUID_INK,
                        loc.clone().add(Math.cos(angle)*r, 0, Math.sin(angle)*r),
                        1, 0, 0, 0, 0);
                }
                if (Math.random() < 0.10) {
                    loc.getWorld().spawnParticle(Particle.DUST,
                        loc.clone().add((Math.random()-.5)*.5, Math.random()*.5, (Math.random()-.5)*.5),
                        1, new Particle.DustOptions(Color.fromRGB(80, 0, 120), 0.5f));
                }
            }
        }.runTaskTimer(plugin, 0L, 3L);
    }

    // ── Active: Shadow Teleport ───────────────────────────────────────────

    @Override
    public ActivationResult activate(PotionSMP plugin, Player player) {
        UUID uid = player.getUniqueId();
        if (plugin.getCooldownManager().isOnCooldown(uid, type()))
            return ActivationResult.ON_COOLDOWN;
        if (inCountdown.contains(uid)) {
            player.sendMessage(PotionUtils.colorize("&5🌀 Already charging Shadow Teleport!"));
            return ActivationResult.SUCCESS;
        }

        Player target = findTarget(player);
        if (target == null) {
            player.sendMessage(PotionUtils.colorize("&cNo valid target nearby!"));
            return ActivationResult.SUCCESS;
        }

        inCountdown.add(uid);
        int cooldown = plugin.getConfig().getInt("potions.teleport.cooldown", 90);
        plugin.getCooldownManager().setCooldown(uid, type(), cooldown);

        player.sendMessage(PotionUtils.colorize(
            "&5🌀 Shadow Teleport targeting: &f" + target.getName() + " &5— 5 seconds..."));
        startCountdown(plugin, player, target);
        return ActivationResult.SUCCESS;
    }

    private Player findTarget(Player player) {
        // Try raycast first
        Entity looked = player.getTargetEntity(60,
            e -> e instanceof Player p && !p.getUniqueId().equals(player.getUniqueId()));
        if (looked instanceof Player p && p.getWorld().equals(player.getWorld())) return p;

        // Fall back to closest
        Player closest = null;
        double minDist = Double.MAX_VALUE;
        for (Player p : player.getWorld().getPlayers()) {
            if (p.getUniqueId().equals(player.getUniqueId())) continue;
            double d = p.getLocation().distanceSquared(player.getLocation());
            if (d < minDist) { minDist = d; closest = p; }
        }
        return closest;
    }

    private void startCountdown(PotionSMP plugin, Player player, Player target) {
        UUID uid   = player.getUniqueId();
        World world = player.getWorld();

        new BukkitRunnable() {
            int secondsLeft = 5;
            int ticks = 0;

            @Override
            public void run() {
                if (!player.isOnline() || !inCountdown.contains(uid)) { cancel(); return; }
                if (ticks > 0 && ticks % 20 == 0) secondsLeft--;

                Location loc = player.getLocation().add(0, 1, 0);
                double progress  = 1.0 - secondsLeft / 5.0 + (ticks % 20) / 100.0;
                int pts          = (int)(3 + progress * 12);
                double r         = 2.0 - progress * 1.5;

                for (int i = 0; i < pts; i++) {
                    double a = (ticks * 0.3) + (Math.PI * 2 / pts) * i;
                    Location p = loc.clone().add(Math.cos(a)*r, (Math.random()-.5)*2, Math.sin(a)*r);
                    world.spawnParticle(Particle.PORTAL,         p, 2, 0.1,0.1,0.1, 0.3);
                    world.spawnParticle(Particle.REVERSE_PORTAL, p, 1, 0.1,0.1,0.1, 0.1);
                    world.spawnParticle(Particle.SQUID_INK,      p, 1, 0.1,0.1,0.1, 0.02);
                }

                if (ticks % 20 == 0) {
                    String col = secondsLeft <= 1 ? "§c" : secondsLeft <= 2 ? "§e" : "§d";
                    player.sendActionBar(net.kyori.adventure.text.Component.text(
                        "§5🌀 Shadow Teleport: " + col + secondsLeft + "s → §f" + target.getName()));
                    world.playSound(loc, Sound.BLOCK_BEACON_AMBIENT, 0.6f, 1.5f + (5 - secondsLeft) * 0.1f);
                }

                ticks++;
                if (secondsLeft <= 0) {
                    inCountdown.remove(uid);
                    cancel();
                    executeTeleport(plugin, player, target);
                }
            }
        }.runTaskTimer(plugin, 0L, 1L);
    }

    private void executeTeleport(PotionSMP plugin, Player player, Player target) {
        if (!player.isOnline() || !target.isOnline()) return;
        World  world = player.getWorld();
        Location from = player.getLocation().clone();
        Location to   = target.getLocation().clone();

        // Pre-teleport origin burst
        world.spawnParticle(Particle.PORTAL,         from.clone().add(0,1,0), 40, 0.5,1,0.5, 0.4);
        world.spawnParticle(Particle.REVERSE_PORTAL, from.clone().add(0,1,0), 30, 0.5,1,0.5, 0.2);
        world.playSound(from, Sound.ENTITY_ENDERMAN_TELEPORT, 1f, 0.7f);

        player.teleport(to);

        // Arrival effects
        World dest = to.getWorld();
        dest.spawnParticle(Particle.PORTAL,         to.clone().add(0,1,0), 60, 0.6,1.2,0.6, 0.5);
        dest.spawnParticle(Particle.REVERSE_PORTAL, to.clone().add(0,1,0), 40, 0.5,1.0,0.5, 0.3);
        dest.spawnParticle(Particle.END_ROD,         to.clone().add(0,2,0), 25, 0.4,0.6,0.4, 0.2);
        spawnShockwaveRing(dest, to, 4.0, plugin);

        dest.playSound(to, Sound.ENTITY_ENDERMAN_TELEPORT,  1.2f, 0.8f);
        dest.playSound(to, Sound.ENTITY_WARDEN_SONIC_CHARGE,0.4f, 0.3f);

        // Target debuff
        int debuffDur = plugin.getConfig().getInt("potions.teleport.debuff-duration-ticks", 60);
        target.addPotionEffect(new PotionEffect(PotionEffectType.NAUSEA,    debuffDur, 0, false, false));
        target.addPotionEffect(new PotionEffect(PotionEffectType.BLINDNESS, debuffDur, 0, false, false));
        target.sendTitle("§5§l!!!", "§8Shadow teleported to you!", 2, 15, 5);
        target.getWorld().playSound(target.getLocation(), Sound.ITEM_CHORUS_FRUIT_TELEPORT, 1.2f, 0.5f);
        target.sendMessage(PotionUtils.colorize("&5☠ &f" + player.getName() + " &5shadow-teleported to you!"));

        player.sendActionBar(net.kyori.adventure.text.Component.text(
            "§5🌀 Teleported to §f" + target.getName()));

        // Re-apply invisibility after 2 ticks
        plugin.getServer().getScheduler().runTaskLater(plugin, () -> {
            if (player.isOnline() &&
                plugin.getSlotManager().hasEquipped(player.getUniqueId(), PotionType.TELEPORT))
                applyInvisibility(player);
        }, 2L);
    }

    private void spawnShockwaveRing(World world, Location center, double maxRadius, PotionSMP plugin) {
        new BukkitRunnable() {
            double r = 0.3;
            int    t = 0;
            @Override
            public void run() {
                if (r > maxRadius || t > 12) { cancel(); return; }
                int pts = (int)(r * 10) + 8;
                for (int i = 0; i < pts; i++) {
                    double a = (Math.PI * 2 / pts) * i;
                    Location p = new Location(world,
                        center.getX() + r*Math.cos(a), center.getY()+0.1, center.getZ() + r*Math.sin(a));
                    world.spawnParticle(Particle.DUST, p, 1,
                        new Particle.DustOptions(Color.fromRGB(100, 0, 200), 1.5f));
                    world.spawnParticle(Particle.SQUID_INK, p, 1, 0,0,0, 0.01);
                }
                r += maxRadius / 10.0;
                t++;
            }
        }.runTaskTimer(plugin, 0L, 1L);
    }
}
