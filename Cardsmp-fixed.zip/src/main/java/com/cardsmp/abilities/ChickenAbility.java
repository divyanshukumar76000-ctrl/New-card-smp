package com.cardsmp.abilities;

import com.cardsmp.CardsmpPlugin;
import com.cardsmp.cards.CardType;
import com.cardsmp.managers.ActiveCardManager;
import com.cryptomorin.xseries.XSound;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.entity.Chicken;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class ChickenAbility {

    private static final int CHICKEN_COUNT = 10;
    private static final double SPAWN_HEIGHT = 25.0;
    private static final double EXPLOSION_RADIUS = 5.0;
    private static final double EXPLOSION_DAMAGE = 20.0;

    public static void activate(Player owner, CardsmpPlugin plugin) {
        UUID ownerUUID = owner.getUniqueId();
        ActiveCardManager manager = plugin.getActiveCardManager();

        manager.setActiveCard(ownerUUID, CardType.CHICKEN);

        Location base = owner.getLocation().clone();
        List<Chicken> chickens = new ArrayList<>();

        // Spawn chickens high in the sky
        for (int i = 0; i < CHICKEN_COUNT; i++) {
            double offsetX = (Math.random() - 0.5) * 10;
            double offsetZ = (Math.random() - 0.5) * 10;
            Location spawnLoc = base.clone().add(offsetX, SPAWN_HEIGHT, offsetZ);
            Chicken chicken = (Chicken) owner.getWorld().spawnEntity(spawnLoc, EntityType.CHICKEN);
            chicken.setAI(false);
            chicken.setGravity(true);
            manager.addEntity(ownerUUID, chicken);
            chickens.add(chicken);
        }

        XSound.matchXSound("ENTITY_CHICKEN_HURT").ifPresent(s ->
            owner.getWorld().playSound(base, s.get(), 2f, 0.5f));

        int[] ticks = {0};

        BukkitTask task = new BukkitRunnable() {
            @Override
            public void run() {
                ticks[0]++;

                List<Chicken> toExplode = new ArrayList<>();
                for (Chicken chicken : new ArrayList<>(chickens)) {
                    if (chicken.isDead()) {
                        toExplode.add(chicken);
                        continue;
                    }
                    // White ash trail while falling
                    if (ticks[0] % 2 == 0) {
                        chicken.getWorld().spawnParticle(Particle.WHITE_ASH,
                            chicken.getLocation(), 5, 0.2, 0.2, 0.2, 0.02);
                    }
                    // Check for ground contact
                    if (chicken.isOnGround()) {
                        toExplode.add(chicken);
                    }
                }

                for (Chicken chicken : toExplode) {
                    if (!chicken.isDead()) explodeChicken(chicken, ownerUUID, owner, manager, plugin);
                    chickens.remove(chicken);
                }

                // Card ends when all chickens have exploded or 10s safety timeout
                if (chickens.isEmpty() || ticks[0] >= 200) {
                    manager.cleanupPlayer(ownerUUID);
                    cancel();
                }
            }
        }.runTaskTimer(plugin, 1L, 2L);

        manager.addTask(ownerUUID, task);
    }

    private static void explodeChicken(Chicken chicken, UUID ownerUUID, Player owner,
                                       ActiveCardManager manager, CardsmpPlugin plugin) {
        Location loc = chicken.getLocation();

        // Visual explosion
        loc.getWorld().spawnParticle(Particle.EXPLOSION_EMITTER, loc, 1);
        loc.getWorld().spawnParticle(Particle.WHITE_ASH, loc, 40, 2, 2, 2, 0.05);

        // Sound
        XSound.matchXSound("ENTITY_GENERIC_EXPLODE").ifPresent(s ->
            loc.getWorld().playSound(loc, s.get(), 2f, 1f));
        XSound.matchXSound("ENTITY_CHICKEN_HURT").ifPresent(s ->
            loc.getWorld().playSound(loc, s.get(), 1.5f, 0.8f));

        // Damage nearby enemy players — owner is FULLY IMMUNE (ABSOLUTE RULE)
        for (Entity entity : loc.getWorld().getNearbyEntities(loc, EXPLOSION_RADIUS, EXPLOSION_RADIUS, EXPLOSION_RADIUS)) {
            if (entity instanceof Player victim) {
                if (victim.getUniqueId().equals(ownerUUID)) continue;
                victim.damage(EXPLOSION_DAMAGE);
            }
        }

        // Remove chicken
        manager.removeEntityFromTracking(ownerUUID, chicken);
    }
}