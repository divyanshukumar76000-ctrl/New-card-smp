package com.cardsmp.inventory.impl;

import com.cardsmp.CardsmpPlugin;
import com.cardsmp.cards.CardItem;
import com.cardsmp.cards.CardType;
import com.cardsmp.inventory.InventoryButton;
import com.cardsmp.inventory.InventoryGUI;
import com.cryptomorin.xseries.XSound;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

public class CardsGUI extends InventoryGUI {

    private final CardsmpPlugin plugin;

    // GUI slot for each card type (index matches CardType.ordinal())
    private static final int[] SLOTS = {10, 11, 12, 13, 14, 15, 16};

    public CardsGUI(CardsmpPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    protected Inventory createInventory() {
        return Bukkit.createInventory(null, 27, "§6Cards SMP");
    }

    @Override
    public void decorate(Player player) {
        CardType[] types = CardType.values();
        for (int i = 0; i < types.length; i++) {
            CardType type = types[i];
            int slot = SLOTS[i];
            addButton(slot, buildCardButton(type));
        }
        super.decorate(player);
    }

    private InventoryButton buildCardButton(CardType type) {
        return new InventoryButton()
            .creator(p -> CardItem.createCard(plugin, type))
            .consumer(event -> {
                Player clicker = (Player) event.getWhoClicked();
                ItemStack card = CardItem.createCard(plugin, type);
                if (card == null) return;
                clicker.getInventory().addItem(card);
                XSound.matchXSound("ENTITY_ITEM_PICKUP").ifPresent(s ->
                    clicker.getWorld().playSound(clicker.getLocation(), s.get(), 1f, 1.2f));
            });
    }
}