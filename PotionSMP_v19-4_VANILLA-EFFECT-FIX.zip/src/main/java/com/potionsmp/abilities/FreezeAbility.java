package com.potionsmp.abilities;

import com.potionsmp.PotionSMP;
import com.potionsmp.managers.ParticleManager;
import com.potionsmp.utils.PotionType;
import com.potionsmp.utils.PotionUtils;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;

public class FreezeAbility implements Ability {

    @Override
    public PotionType type() { return PotionType.FREEZE; }

    @Override
    public void onUnequip(PotionSMP plugin, Player player) {
        plugin.getParticleManager().cancelAura(player.getUniqueId());
    }

    @Override
    public void onHit(PotionSMP plugin, Player player, LivingEntity target) {
        int newCount = plugin.getHitCounterManager().registerHit(
            player.getUniqueId(), type(), target.getUniqueId(),
            player.getWorld().getFullTime());
        if (newCount == -1) return;

        int threshold = plugin.getConfig().getInt("potions.freeze.passive-hits", 10);
        if (newCount >= threshold) {
            plugin.getHitCounterManager().reset(player.getUniqueId(), type());
            int stunDur = plugin.getConfig().getInt("potions.freeze.passive-stun-duration", 20);
            plugin.getFrozenPlayerManager().freezeEntity(target, stunDur);

            // Passive particle burst
            ParticleManager.spawnFreezePassiveParticles(target.getLocation().clone().add(0, 1, 0));
            target.getWorld().playSound(target.getLocation(), Sound.BLOCK_GLASS_BREAK, 1f, 1.5f);
            player.sendMessage(PotionUtils.colorize("&b❄ Passive freeze triggered!"));
        } else {
            target.getWorld().spawnParticle(Particle.SNOWFLAKE,
                target.getLocation().add(0, 1, 0), 2, 0.15, 0.15, 0.15, 0.01);
        }
    }

    @Override
    public ActivationResult activate(PotionSMP plugin, Player player) {
        if (plugin.getCooldownManager().isOnCooldown(player.getUniqueId(), type()))
            return ActivationResult.ON_COOLDOWN;

        int radius = plugin.getConfig().getInt("potions.freeze.active-radius", 10);
        int freezeDur = plugin.getConfig().getInt("potions.freeze.active-freeze-duration", 60);
        int cooldown = plugin.getConfig().getInt("potions.freeze.active-cooldown", 45);

        plugin.getCooldownManager().setCooldown(player.getUniqueId(), type(), cooldown);
        player.sendMessage(PotionUtils.msg("freeze-active"));

        Location center = player.getLocation();

        // Cast sound cue — the old massive SNOWFLAKE/ITEM_SNOWBALL burst
        // here (380 particles) has been removed. The Frost Barrier's own
        // activation animation (started below via startFreezeAura) now
        // plays a clean 4-phase intro instead.
        center.getWorld().playSound(center, Sound.ENTITY_ELDER_GUARDIAN_CURSE, 1.5f, 0.5f);
        center.getWorld().playSound(center, Sound.BLOCK_POWDER_SNOW_STEP, 1.5f, 0.5f);

        // Freeze all nearby entities
        for (Entity e : center.getWorld().getNearbyEntities(center, radius, radius, radius)) {
            if (e instanceof LivingEntity le && !e.getUniqueId().equals(player.getUniqueId())) {
                plugin.getFrozenPlayerManager().freezeEntity(le, freezeDur);

                // Frost Impact — short visual feedback at the moment each
                // target is frozen (visual only; freezeEntity() above is
                // what actually applies the freeze).
                ParticleManager.spawnFreezePassiveParticles(le.getLocation().clone().add(0, 1, 0));

                if (le instanceof Player frozen)
                    frozen.sendMessage(PotionUtils.colorize("&b❄ Frozen by &f" + player.getName() + "&b!"));
            }
        }

        // Frost Barrier aura around the caster for the freeze duration.
        // This is now the ONLY particle system for Freeze's active ability
        // — the old second, simultaneously-running spinning-ring task
        // that used to run alongside it has been removed (same class of
        // dual-particle-system issue fixed earlier for Fire and Regen).
        plugin.getParticleManager().startFreezeAura(player, freezeDur);

        return ActivationResult.SUCCESS;
    }
}
