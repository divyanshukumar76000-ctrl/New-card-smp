package com.elementallegends.items;

import com.elementallegends.util.ItemKeys;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Material;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ArmorMeta;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.List;

/**
 * Builds every ElementalLegends item. Each item gets:
 *  - custom display name + lore
 *  - enchant glow (hidden enchant + HIDE_ENCHANTS flag)
 *  - unbreakable + hidden attributes
 *  - a CustomModelData value so a resource pack can retexture it
 *  - a PersistentDataContainer tag identifying which item it is
 */
public final class ItemFactory {

    private ItemFactory() {}

    // Custom model data values reserved for the resource pack.
    public static final int CMD_FIRE_SWORD = 1001;
    public static final int CMD_WATER_SWORD = 1002;
    public static final int CMD_THUNDER_SWORD = 1003;
    public static final int CMD_VOID_MACE = 1004;
    public static final int CMD_VOID_HELMET = 1005;
    public static final int CMD_VOID_CHESTPLATE = 1006;
    public static final int CMD_VOID_LEGGINGS = 1007;
    public static final int CMD_VOID_BOOTS = 1008;

    public static ItemStack fireSword() {
        ItemStack item = base(Material.NETHERITE_SWORD, CMD_FIRE_SWORD, ItemKeys.ItemId.FIRE_SWORD);
        ItemMeta meta = item.getItemMeta();
        meta.displayName(Component.text("Inferno Blade", NamedTextColor.RED, TextDecoration.BOLD)
                .decoration(TextDecoration.ITALIC, false));
        meta.lore(lore(
                NamedTextColor.GRAY, "A blade forged in the heart of the Nether.",
                NamedTextColor.GRAY, "",
                NamedTextColor.GOLD, "Passive:",
                NamedTextColor.GRAY, "  Fire Resistance, Lava Immunity",
                NamedTextColor.GRAY, "",
                NamedTextColor.RED, "Shift + Right Click: Inferno Strike",
                NamedTextColor.RED, "Shift + Left Click: Inferno Apocalypse"
        ));
        item.setItemMeta(meta);
        return item;
    }

    public static ItemStack waterSword() {
        ItemStack item = base(Material.DIAMOND_SWORD, CMD_WATER_SWORD, ItemKeys.ItemId.WATER_SWORD);
        ItemMeta meta = item.getItemMeta();
        meta.displayName(Component.text("Ocean Blade", NamedTextColor.AQUA, TextDecoration.BOLD)
                .decoration(TextDecoration.ITALIC, false));
        meta.lore(lore(
                NamedTextColor.GRAY, "Carved from crystallized ocean current.",
                NamedTextColor.GRAY, "",
                NamedTextColor.GOLD, "Passive:",
                NamedTextColor.GRAY, "  Water Breathing, Dolphin's Grace,",
                NamedTextColor.GRAY, "  Underwater Night Vision, Water Walking",
                NamedTextColor.GRAY, "",
                NamedTextColor.AQUA, "Shift + Right Click: Ocean Curse",
                NamedTextColor.AQUA, "Shift + Left Click: TNT Water Trap"
        ));
        item.setItemMeta(meta);
        return item;
    }

    public static ItemStack thunderSword() {
        ItemStack item = base(Material.GOLDEN_SWORD, CMD_THUNDER_SWORD, ItemKeys.ItemId.THUNDER_SWORD);
        ItemMeta meta = item.getItemMeta();
        meta.displayName(Component.text("Thunder King Blade", NamedTextColor.YELLOW, TextDecoration.BOLD)
                .decoration(TextDecoration.ITALIC, false));
        meta.lore(lore(
                NamedTextColor.GRAY, "Crackling with the fury of a storm god.",
                NamedTextColor.GRAY, "",
                NamedTextColor.GOLD, "Passive:",
                NamedTextColor.GRAY, "  Speed I, Jump Boost I, Lightning Immunity",
                NamedTextColor.GRAY, "",
                NamedTextColor.YELLOW, "Shift + Right Click: Thunder Storm",
                NamedTextColor.YELLOW, "Shift + Left Click: Divine Thunder"
        ));
        item.setItemMeta(meta);
        return item;
    }

    public static ItemStack voidMace() {
        ItemStack item = base(Material.MACE, CMD_VOID_MACE, ItemKeys.ItemId.VOID_MACE);
        ItemMeta meta = item.getItemMeta();
        meta.displayName(Component.text("Void Destroyer", NamedTextColor.DARK_PURPLE, TextDecoration.BOLD)
                .decoration(TextDecoration.ITALIC, false));
        meta.lore(lore(
                NamedTextColor.GRAY, "A weapon torn from the fabric of the Void.",
                NamedTextColor.GRAY, "",
                NamedTextColor.GOLD, "Passive:",
                NamedTextColor.GRAY, "  Strength II, Resistance I,",
                NamedTextColor.GRAY, "  Knockback Resistance, Slow Falling",
                NamedTextColor.GRAY, "",
                NamedTextColor.LIGHT_PURPLE, "Shift + Right Click: Void Smash",
                NamedTextColor.LIGHT_PURPLE, "Shift + Left Click: Void Meteor"
        ));
        item.setItemMeta(meta);
        return item;
    }

    public static ItemStack voidHelmet() {
        return armorPiece(Material.NETHERITE_HELMET, CMD_VOID_HELMET, ItemKeys.ItemId.VOID_HELMET, "Void Helmet");
    }

    public static ItemStack voidChestplate() {
        return armorPiece(Material.NETHERITE_CHESTPLATE, CMD_VOID_CHESTPLATE, ItemKeys.ItemId.VOID_CHESTPLATE, "Void Chestplate");
    }

    public static ItemStack voidLeggings() {
        return armorPiece(Material.NETHERITE_LEGGINGS, CMD_VOID_LEGGINGS, ItemKeys.ItemId.VOID_LEGGINGS, "Void Leggings");
    }

    public static ItemStack voidBoots() {
        return armorPiece(Material.NETHERITE_BOOTS, CMD_VOID_BOOTS, ItemKeys.ItemId.VOID_BOOTS, "Void Boots");
    }

    private static ItemStack armorPiece(Material material, int cmd, ItemKeys.ItemId id, String name) {
        ItemStack item = base(material, cmd, id);
        ArmorMeta meta = (ArmorMeta) item.getItemMeta();
        meta.displayName(Component.text(name, NamedTextColor.DARK_PURPLE, TextDecoration.BOLD)
                .decoration(TextDecoration.ITALIC, false));
        meta.lore(lore(
                NamedTextColor.GRAY, "Forged from crystallized Void energy.",
                NamedTextColor.GRAY, "",
                NamedTextColor.GOLD, "Full Set Passive:",
                NamedTextColor.GRAY, "  Speed II, Resistance I, Regeneration I,",
                NamedTextColor.GRAY, "  Night Vision, Fire & Lightning Immunity,",
                NamedTextColor.GRAY, "  Knockback Resistance, Slow Falling",
                NamedTextColor.GRAY, "",
                NamedTextColor.LIGHT_PURPLE, "Shift + Right Click: Void Arrow Apocalypse",
                NamedTextColor.LIGHT_PURPLE, "Shift + Left Click: Void Dimension Prison"
        ));
        item.setItemMeta(meta);
        return item;
    }

    /** Shared base: unbreakable, glow, hidden attributes/flags, model data + PDC tag. */
    private static ItemStack base(Material material, int customModelData, ItemKeys.ItemId id) {
        ItemStack item = new ItemStack(material);
        ItemMeta meta = item.getItemMeta();

        meta.setUnbreakable(true);
        meta.setCustomModelData(customModelData);

        meta.addItemFlags(
                ItemFlag.HIDE_ATTRIBUTES,
                ItemFlag.HIDE_UNBREAKABLE,
                ItemFlag.HIDE_ENCHANTS,
                ItemFlag.HIDE_DYE
        );

        // Enchant glow without a functional enchantment effect.
        meta.addEnchant(Enchantment.LURE, 1, true);

        meta.getPersistentDataContainer().set(ItemKeys.ITEM_ID, org.bukkit.persistence.PersistentDataType.STRING, id.name());

        item.setItemMeta(meta);
        return item;
    }

    private static List<Component> lore(Object... pairs) {
        java.util.ArrayList<Component> lines = new java.util.ArrayList<>();
        for (int i = 0; i < pairs.length; i += 2) {
            NamedTextColor color = (NamedTextColor) pairs[i];
            String text = (String) pairs[i + 1];
            lines.add(Component.text(text, color).decoration(TextDecoration.ITALIC, false));
        }
        return lines;
    }

    public static ItemKeys.ItemId idOf(ItemStack item) {
        if (item == null || !item.hasItemMeta()) return null;
        String raw = item.getItemMeta().getPersistentDataContainer()
                .get(ItemKeys.ITEM_ID, org.bukkit.persistence.PersistentDataType.STRING);
        if (raw == null) return null;
        try {
            return ItemKeys.ItemId.valueOf(raw);
        } catch (IllegalArgumentException e) {
            return null;
        }
    }
}
