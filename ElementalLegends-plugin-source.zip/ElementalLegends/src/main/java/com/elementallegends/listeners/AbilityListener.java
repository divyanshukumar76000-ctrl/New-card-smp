package com.elementallegends.listeners;

import com.destroystokyo.paper.event.player.PlayerArmSwingEvent;
import com.elementallegends.items.ItemFactory;
import com.elementallegends.managers.AbilityManager;
import com.elementallegends.managers.CooldownManager;
import com.elementallegends.util.ItemKeys;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.Plugin;

/**
 * Routes shift+right-click and shift+left-click on ElementalLegends items to
 * the correct ability, respecting per-ability cooldowns. Uses Paper's
 * PlayerArmSwingEvent to detect left-click "ability 2" triggers even when the
 * swing doesn't hit a block or entity.
 */
public class AbilityListener implements Listener {

    private final Plugin plugin;
    private final CooldownManager cooldowns;
    private final AbilityManager abilities;

    public AbilityListener(Plugin plugin, CooldownManager cooldowns, AbilityManager abilities) {
        this.plugin = plugin;
        this.cooldowns = cooldowns;
        this.abilities = abilities;
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = false)
    public void onRightClick(PlayerInteractEvent event) {
        if (event.getHand() != EquipmentSlot.HAND) return;
        if (event.getAction() != Action.RIGHT_CLICK_AIR && event.getAction() != Action.RIGHT_CLICK_BLOCK) return;

        Player player = event.getPlayer();
        if (!player.isSneaking()) return;

        ItemStack held = player.getInventory().getItemInMainHand();
        ItemKeys.ItemId id = ItemFactory.idOf(held);
        if (id == null || !isSwordOrMace(id)) return;

        if (!player.hasPermission("elementallegends.use")) return;
        if (!cooldowns.debounce(player, 250)) return;

        triggerAbility1(player, id);
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onLeftSwing(PlayerArmSwingEvent event) {
        if (event.getHand() != EquipmentSlot.HAND) return;

        Player player = event.getPlayer();
        if (!player.isSneaking()) return;

        ItemStack held = player.getInventory().getItemInMainHand();
        ItemKeys.ItemId id = ItemFactory.idOf(held);
        if (id == null || !isSwordOrMace(id)) return;

        if (!player.hasPermission("elementallegends.use")) return;
        if (!cooldowns.debounce(player, 250)) return;

        triggerAbility2(player, id);
    }

    /** Void Armor abilities are triggered off the chestplate slot instead of a held item. */
    @EventHandler(priority = EventPriority.HIGH)
    public void onRightClickArmor(PlayerInteractEvent event) {
        if (event.getHand() != EquipmentSlot.HAND) return;
        if (event.getAction() != Action.RIGHT_CLICK_AIR && event.getAction() != Action.RIGHT_CLICK_BLOCK) return;

        Player player = event.getPlayer();
        if (!player.isSneaking()) return;
        if (!isWearingFullVoidArmor(player)) return;
        if (!player.hasPermission("elementallegends.use")) return;
        if (!cooldowns.debounce(player, 250)) return;

        String key = "void_armor_ability1";
        if (cooldowns.isOnCooldown(player, key)) {
            notifyCooldown(player, "Void Armor", key);
            return;
        }
        abilities.voidArrowApocalypse(player);
        cooldowns.setCooldown(player, key, plugin.getConfig().getInt("items.void-armor.ability1.cooldown", 30));
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onLeftSwingArmor(PlayerArmSwingEvent event) {
        if (event.getHand() != EquipmentSlot.HAND) return;

        Player player = event.getPlayer();
        if (!player.isSneaking()) return;
        if (!isWearingFullVoidArmor(player)) return;
        if (!player.hasPermission("elementallegends.use")) return;
        if (!cooldowns.debounce(player, 250)) return;

        String key = "void_armor_ability2";
        if (cooldowns.isOnCooldown(player, key)) {
            notifyCooldown(player, "Void Armor", key);
            return;
        }
        abilities.voidDimensionPrison(player);
        cooldowns.setCooldown(player, key, plugin.getConfig().getInt("items.void-armor.ability2.cooldown", 7200));
    }

    // ----------------------------------------------------------------------

    private void triggerAbility1(Player player, ItemKeys.ItemId id) {
        String key = id.name() + "_ability1";
        if (cooldowns.isOnCooldown(player, key)) {
            notifyCooldown(player, displayName(id), key);
            return;
        }

        switch (id) {
            case FIRE_SWORD -> abilities.infernoStrike(player);
            case WATER_SWORD -> abilities.oceanCurse(player);
            case THUNDER_SWORD -> abilities.thunderStorm(player);
            case VOID_MACE -> abilities.voidSmash(player);
            default -> { return; }
        }
        cooldowns.setCooldown(player, key, cooldownFor(id, 1));
    }

    private void triggerAbility2(Player player, ItemKeys.ItemId id) {
        String key = id.name() + "_ability2";
        if (cooldowns.isOnCooldown(player, key)) {
            notifyCooldown(player, displayName(id), key);
            return;
        }

        switch (id) {
            case FIRE_SWORD -> abilities.infernoApocalypse(player);
            case WATER_SWORD -> abilities.tntWaterTrap(player);
            case THUNDER_SWORD -> abilities.divineThunder(player);
            case VOID_MACE -> abilities.voidMeteor(player);
            default -> { return; }
        }
        cooldowns.setCooldown(player, key, cooldownFor(id, 2));
    }

    private int cooldownFor(ItemKeys.ItemId id, int ability) {
        String path = switch (id) {
            case FIRE_SWORD -> "items.fire-sword.ability" + ability + ".cooldown";
            case WATER_SWORD -> "items.water-sword.ability" + ability + ".cooldown";
            case THUNDER_SWORD -> "items.thunder-sword.ability" + ability + ".cooldown";
            case VOID_MACE -> "items.void-mace.ability" + ability + ".cooldown";
            default -> "cooldowns.default-seconds";
        };
        return plugin.getConfig().getInt(path, plugin.getConfig().getInt("cooldowns.default-seconds", 30));
    }

    private void notifyCooldown(Player player, String itemName, String key) {
        long remaining = cooldowns.secondsRemaining(player, key);
        String msg = plugin.getConfig().getString("messages.cooldown", "&c%item% is on cooldown! &7(%time%s remaining)")
                .replace("%item%", itemName)
                .replace("%time%", String.valueOf(remaining));
        player.sendActionBar(Component.text(org.bukkit.ChatColor.translateAlternateColorCodes('&', msg)));
    }

    private String displayName(ItemKeys.ItemId id) {
        return switch (id) {
            case FIRE_SWORD -> "Inferno Blade";
            case WATER_SWORD -> "Ocean Blade";
            case THUNDER_SWORD -> "Thunder King Blade";
            case VOID_MACE -> "Void Destroyer";
            default -> "Item";
        };
    }

    private boolean isSwordOrMace(ItemKeys.ItemId id) {
        return id == ItemKeys.ItemId.FIRE_SWORD || id == ItemKeys.ItemId.WATER_SWORD
                || id == ItemKeys.ItemId.THUNDER_SWORD || id == ItemKeys.ItemId.VOID_MACE;
    }

    private boolean isWearingFullVoidArmor(Player player) {
        var inv = player.getInventory();
        return ItemFactory.idOf(inv.getHelmet()) == ItemKeys.ItemId.VOID_HELMET
                && ItemFactory.idOf(inv.getChestplate()) == ItemKeys.ItemId.VOID_CHESTPLATE
                && ItemFactory.idOf(inv.getLeggings()) == ItemKeys.ItemId.VOID_LEGGINGS
                && ItemFactory.idOf(inv.getBoots()) == ItemKeys.ItemId.VOID_BOOTS;
    }
}
