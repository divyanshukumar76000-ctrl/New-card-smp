package com.cardsmp.abilities;

import com.cardsmp.CardsmpPlugin;
import com.cardsmp.cards.CardType;
import com.cardsmp.managers.ActiveCardManager;
import com.cryptomorin.xseries.XSound;
import org.bukkit.Color;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Phantom;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;

import java.util.UUID;

public class PhantomAbility {

    private static final int PHANTOM_COUNT = 4;
    // 20s duration = 200 iterations at 2-tick interval
    private static final int DURATION_ITERATIONS = 200;
    private static final double ORBIT_RADIUS = 4.0;
    private static final double ORBIT_HEIGHT = 2.5;

    public static void activate(Player owner, CardsmpPlugin plugin) {
        UUID ownerUUID = owner.getUniqueId();
        ActiveCardManager manager = plugin.getActiveCardManager();

        manager.setActiveCard(ownerUUID, CardType.PHANTOM);
        manager.setCombatTriggered(ownerUUID, false);

        Location spawnLoc = owner.getLocation();

        // Spawn phantoms with AI OFF (orbit controlled manually)
        for (int i = 0; i < PHANTOM_COUNT; i++) {
            double angle = 2 * Math.PI * i / PHANTOM_COUNT;
            Location phantomLoc = spawnLoc.clone().add(
                Math.cos(angle) * ORBIT_RADIUS, ORBIT_HEIGHT, Math.sin(angle) * ORBIT_RADIUS);
            Phantom phantom = (Phantom) owner.getWorld().spawnEntity(phantomLoc, EntityType.PHANTOM);
            phantom.setAI(false);
            manager.addEntity(ownerUUID, phantom);
        }

        XSound.matchXSound("ENTITY_PHANTOM_AMBIENT").ifPresent(s ->
            owner.getWorld().playSound(spawnLoc, s.get(), 2f, 0.8f));

        // Dark aura at activation
        spawnLoc.getWorld().spawnParticle(Particle.LARGE_SMOKE, spawnLoc.clone().add(0, 1, 0),
            30, 1.5, 1.5, 1.5, 0.02);
        spawnLoc.getWorld().spawnParticle(Particle.ASH, spawnLoc.clone().add(0, 1, 0),
            20, 1, 1, 1, 0.03);

        int[] ticks = {0};
        int[] orbitAngle = {0};

        BukkitTask task = new BukkitRunnable() {
            @Override
            public void run() {
                if (!owner.isOnline() || !manager.hasActiveCard(ownerUUID)) {
                    cancel();
                    return;
                }

                ticks[0]++;
                boolean combat = manager.isCombatTriggered(ownerUUID);

                int phantomIndex = 0;
                for (Entity entity : manager.getEntities(ownerUUID)) {
                    if (!(entity instanceof Phantom phantom) || phantom.isDead()) {
                        phantomIndex++;
                        continue;
                    }

                    if (!combat) {
                        // Orbit around owner
                        double a = Math.toRadians(orbitAngle[0] + (360.0 / PHANTOM_COUNT) * phantomIndex);
                        Location center = owner.getLocation().clone().add(0, ORBIT_HEIGHT, 0);
                        Location orbitPos = center.clone().add(
                            Math.cos(a) * ORBIT_RADIUS, 0, Math.sin(a) * ORBIT_RADIUS);
                        phantom.teleport(orbitPos);
                    } else {
                        // Enable AI for natural combat
                        if (!phantom.hasAI()) phantom.setAI(true);
                        if (ticks[0] % 20 == 0) {
                            Player enemy = manager.getNearestEnemy(owner, phantom.getLocation(), 25.0);
                            if (enemy != null) phantom.setTarget(enemy);
                        }
                    }

                    // Smoke trail every run
                    phantom.getWorld().spawnParticle(Particle.LARGE_SMOKE,
                        phantom.getLocation(), 3, 0.3, 0.3, 0.3, 0.01);

                    phantomIndex++;
                }

                orbitAngle[0] = (orbitAngle[0] + 4) % 360;

                if (ticks[0] >= DURATION_ITERATIONS) {
                    manager.cleanupPlayer(ownerUUID);
                    cancel();
                }
            }
        }.runTaskTimer(plugin, 0L, 2L);

        manager.addTask(ownerUUID, task);
    }
}