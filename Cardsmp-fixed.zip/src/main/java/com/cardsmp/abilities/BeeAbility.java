package com.cardsmp.abilities;

import com.cardsmp.CardsmpPlugin;
import com.cardsmp.cards.CardType;
import com.cardsmp.managers.ActiveCardManager;
import com.cryptomorin.xseries.XSound;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.entity.Bee;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;

import java.util.UUID;

public class BeeAbility {

    private static final int BEE_COUNT = 6;

    public static void activate(Player owner, CardsmpPlugin plugin) {
        UUID ownerUUID = owner.getUniqueId();
        ActiveCardManager manager = plugin.getActiveCardManager();

        manager.setActiveCard(ownerUUID, CardType.BEE);
        manager.setCombatTriggered(ownerUUID, false);

        Location spawnLoc = owner.getLocation();

        // Spawn 6 bees around owner
        for (int i = 0; i < BEE_COUNT; i++) {
            double angle = 2 * Math.PI * i / BEE_COUNT;
            Location beeLoc = spawnLoc.clone().add(Math.cos(angle) * 2, 1, Math.sin(angle) * 2);
            Bee bee = (Bee) owner.getWorld().spawnEntity(beeLoc, EntityType.BEE);
            manager.addEntity(ownerUUID, bee);
        }

        XSound.matchXSound("ENTITY_BEE_LOOP").ifPresent(s ->
            owner.getWorld().playSound(spawnLoc, s.get(), 2f, 1f));

        // Activation honey drip
        spawnLoc.getWorld().spawnParticle(Particle.DRIPPING_HONEY,
            spawnLoc.clone().add(0, 2, 0), 20, 1, 1, 1, 0);

        int[] ticks = {0};

        BukkitTask task = new BukkitRunnable() {
            @Override
            public void run() {
                if (!owner.isOnline() || !manager.hasActiveCard(ownerUUID)) {
                    cancel();
                    return;
                }

                ticks[0]++;
                boolean combat = manager.isCombatTriggered(ownerUUID);

                for (Entity entity : manager.getEntities(ownerUUID)) {
                    if (!(entity instanceof Bee bee) || bee.isDead()) continue;

                    // Honey particle every run
                    if (ticks[0] % 3 == 0) {
                        bee.getWorld().spawnParticle(Particle.DRIPPING_HONEY,
                            bee.getLocation(), 2, 0.2, 0.2, 0.2, 0);
                    }

                    if (!combat) {
                        // Passive: follow owner
                        if (bee.getLocation().distanceSquared(owner.getLocation()) > 25) {
                            bee.getPathfinder().moveTo(owner, 1.0);
                        }
                    } else {
                        // Combat: target nearest enemy every 20 runs
                        if (ticks[0] % 20 == 0) {
                            Player enemy = manager.getNearestEnemy(owner, bee.getLocation(), 25.0);
                            if (enemy != null) {
                                bee.setAnger(100);
                                bee.setTarget(enemy);
                            }
                        }
                    }
                }
                // BEE card has no fixed duration — runs until cleanup event
            }
        }.runTaskTimer(plugin, 0L, 2L);

        manager.addTask(ownerUUID, task);
    }
}