package com.elementallegends.commands;

import com.elementallegends.gui.MenuFactory;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;

public class MenuCommands implements CommandExecutor {

    private final Plugin plugin;

    public MenuCommands(Plugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("This command can only be used in-game.");
            return true;
        }

        if (!player.hasPermission("elementallegends.gui")) {
            player.sendMessage(Component.text("You do not have permission to do that.", NamedTextColor.RED));
            return true;
        }

        switch (label.toLowerCase()) {
            case "sword" -> player.openInventory(MenuFactory.swordMenu());
            case "mace" -> player.openInventory(MenuFactory.maceMenu());
            case "aura" -> player.openInventory(MenuFactory.auraMenu());
            case "elementallegends", "el", "elreload" -> {
                if (!player.hasPermission("elementallegends.admin")) {
                    player.sendMessage(Component.text("You do not have permission to do that.", NamedTextColor.RED));
                    return true;
                }
                if (args.length > 0 && args[0].equalsIgnoreCase("reload")) {
                    plugin.reloadConfig();
                    player.sendMessage(Component.text("ElementalLegends config reloaded.", NamedTextColor.GREEN));
                } else {
                    player.sendMessage(Component.text("Usage: /elementallegends reload", NamedTextColor.YELLOW));
                }
            }
            default -> {
                return false;
            }
        }
        return true;
    }
}
