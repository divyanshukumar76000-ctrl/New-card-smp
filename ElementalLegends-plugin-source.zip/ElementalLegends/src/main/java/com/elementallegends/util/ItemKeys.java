package com.elementallegends.util;

import org.bukkit.NamespacedKey;
import org.bukkit.plugin.Plugin;

/**
 * Central place for the PersistentDataContainer keys used to identify
 * ElementalLegends custom items on any ItemStack.
 */
public final class ItemKeys {

    public static NamespacedKey ITEM_ID;

    private ItemKeys() {}

    public static void init(Plugin plugin) {
        ITEM_ID = new NamespacedKey(plugin, "el_item_id");
    }

    public enum ItemId {
        FIRE_SWORD,
        WATER_SWORD,
        THUNDER_SWORD,
        VOID_MACE,
        VOID_HELMET,
        VOID_CHESTPLATE,
        VOID_LEGGINGS,
        VOID_BOOTS
    }
}
