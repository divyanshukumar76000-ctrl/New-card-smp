package com.potionsmp.managers;

import com.potionsmp.PotionSMP;
import com.potionsmp.utils.PotionType;
import org.bukkit.Color;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.World;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;

import java.util.HashMap;
import java.util.Map;
import java.util.Random;
import java.util.UUID;

/**
 * Manages continuous active-ability particle auras per player.
 * Each ability's active triggers startAura() with its own particle style.
 * Auras auto-cancel after their duration or when stopAura() is called.
 */
public class ParticleManager {

    private final PotionSMP plugin;
    private final Map<UUID, BukkitTask> activeTasks = new HashMap<>();
    private final Random random = new Random();

    public ParticleManager(PotionSMP plugin) {
        this.plugin = plugin;
    }

    // NOTE: the old startFireAura() (small-radius 3-layer spinning body ring,
    // running every tick with embers + trail) has been completely removed.
    // It was a second, independent Fire particle system running
    // *simultaneously* with FireAuraManager's flat 10-block ring — the two
    // together were the actual cause of the reported FPS drop. Fire's
    // active ability now uses ONLY FireAuraManager.activateInfernoAura() for
    // its visual. See FireAbility.activate() / FireAbility.onUnequip().

    // ============================================================
    // FREEZE POTION — FROST BARRIER
    // ============================================================
    //
    // Redesigned from the old dual-ring SNOWFLAKE/ITEM_SNOWBALL cloud
    // (~46 particles every tick, plus periodic 30-particle bursts) into a
    // controlled, segmented "Frost Barrier": one rotating 4-segment ring,
    // a handful of ice spikes, sparse snowflakes, occasional ice shards
    // and frost dust, with its own activation/sustained/ending phases.
    // Signature is unchanged — FreezeAbility.activate() calls this exactly
    // as before. Freeze/damage/duration/cooldown logic is untouched; this
    // method only ever calls Bukkit's particle API.

    private static final double FREEZE_RING_RADIUS = 2.9;
    private static final int FREEZE_RING_SEGMENTS = 4;
    private static final double FREEZE_SEGMENT_SPAN = Math.toRadians(63);
    private static final double FREEZE_SEGMENT_GAP = Math.toRadians(27);
    private static final int FREEZE_PARTICLES_PER_SEGMENT = 6; // 4 segs x 6 = 24 (<=28 target)
    private static final double FREEZE_ROTATION_SPEED = Math.toRadians(1.6); // slow, per draw
    private static final int FREEZE_DRAW_INTERVAL = 2; // ticks — meets the "2-tick rendering" target

    // Activation phase boundaries (in elapsed real ticks)
    private static final int FREEZE_PHASE1_END = 6;   // awakening
    private static final int FREEZE_PHASE2_END = 12;  // energy rise
    private static final int FREEZE_PHASE3_END = 20;  // barrier form
    private static final int FREEZE_PHASE4_END = 24;  // lock / brighten
    private static final int FREEZE_END_TICKS = 14;   // reserved for melt-down at the tail

    private static final Particle.DustOptions FREEZE_ICE_CYAN =
            new Particle.DustOptions(Color.fromRGB(185, 241, 255), 0.9f);
    private static final Particle.DustOptions FREEZE_BRIGHT_BLUE =
            new Particle.DustOptions(Color.fromRGB(125, 214, 255), 0.85f);
    private static final Particle.DustOptions FREEZE_DEEP_FROST =
            new Particle.DustOptions(Color.fromRGB(63, 168, 255), 0.8f);
    private static final Particle.DustOptions FREEZE_HIGHLIGHT =
            new Particle.DustOptions(Color.fromRGB(255, 255, 255), 0.9f);

    public void startFreezeAura(Player player, int durationTicks) {
        cancelAura(player.getUniqueId());

        BukkitTask task = new BukkitRunnable() {
            int ticks = 0;
            double rotation = 0;

            @Override
            public void run() {
                if (ticks >= durationTicks || !player.isOnline() || player.isDead()) {
                    cancel();
                    return;
                }

                Location center = player.getLocation();
                World world = center.getWorld();
                if (world == null) { cancel(); return; }

                rotation = (rotation + FREEZE_ROTATION_SPEED) % (Math.PI * 2);

                int endingStart = Math.max(FREEZE_PHASE4_END, durationTicks - FREEZE_END_TICKS);

                if (ticks < FREEZE_PHASE1_END) {
                    renderFrostAwakening(world, center, ticks);
                } else if (ticks < FREEZE_PHASE2_END) {
                    renderFrostRise(world, center, ticks - FREEZE_PHASE1_END);
                } else if (ticks < FREEZE_PHASE3_END) {
                    double progress = (ticks - FREEZE_PHASE2_END + 1) / (double) (FREEZE_PHASE3_END - FREEZE_PHASE2_END);
                    double eased = 1.0 - Math.pow(1.0 - progress, 3.0);
                    renderFrostRing(world, center, 0.3 + (FREEZE_RING_RADIUS - 0.3) * eased, rotation, 0.7);
                    renderIceSpikes(world, center, rotation, ticks, (int) Math.round(eased * 6));
                } else if (ticks < endingStart) {
                    if (ticks < FREEZE_PHASE4_END) {
                        // Phase 4 — brief brighten/lock moment
                        renderFrostRing(world, center, FREEZE_RING_RADIUS, rotation, 1.3);
                        renderIceSpikes(world, center, rotation, ticks, 8);
                        world.spawnParticle(Particle.DUST, center.clone().add(0, 1.1, 0),
                                4, 0.2, 0.2, 0.2, 0, FREEZE_HIGHLIGHT);
                    } else {
                        renderSustainedFrost(world, center, rotation, ticks);
                    }
                } else {
                    renderFrostEnding(world, center, rotation, ticks - endingStart,
                            durationTicks - endingStart);
                }

                ticks += FREEZE_DRAW_INTERVAL;
            }
        }.runTaskTimer(plugin, 0L, FREEZE_DRAW_INTERVAL);
        activeTasks.put(player.getUniqueId(), task);
    }

    /** Phase 1 — small cold particles gathering at the player's feet. */
    private void renderFrostAwakening(World world, Location center, int tick) {
        double progress = (tick + 1) / (double) FREEZE_PHASE1_END;
        int count = 5;
        for (int i = 0; i < count; i++) {
            double angle = (Math.PI * 2 * i / count) + tick * 0.3;
            double radius = 0.25 + progress * 0.2;
            double y = 0.1 + progress * 0.3;
            Location p = center.clone().add(Math.cos(angle) * radius, y, Math.sin(angle) * radius);
            world.spawnParticle(Particle.DUST, p, 1, 0, 0, 0, 0, pickFreezeDust(i));
        }
    }

    /** Phase 2 — frost spirals upward from feet toward chest height. */
    private void renderFrostRise(World world, Location center, int tick) {
        double progress = (tick + 1) / (double) (FREEZE_PHASE2_END - FREEZE_PHASE1_END);
        int count = 6;
        for (int i = 0; i < count; i++) {
            double spin = tick * 0.5 + i * (Math.PI * 2 / count);
            double radius = 0.3 + progress * 0.5;
            double y = 0.15 + progress * 1.3;
            Location p = center.clone().add(Math.cos(spin) * radius, y, Math.sin(spin) * radius);
            world.spawnParticle(Particle.DUST, p, 1, 0, 0, 0, 0, pickFreezeDust(i));
        }
    }

    /**
     * Main 4-segment rotating ring. Gaps between segments keep it from
     * reading as a solid circle. ~24 particles per draw at full intensity.
     */
    private void renderFrostRing(World world, Location center, double radius, double rotation, double intensity) {
        double y = center.getY() + 1.1;
        for (int segment = 0; segment < FREEZE_RING_SEGMENTS; segment++) {
            double start = rotation + segment * (FREEZE_SEGMENT_SPAN + FREEZE_SEGMENT_GAP);
            for (int i = 0; i < FREEZE_PARTICLES_PER_SEGMENT; i++) {
                double t = i / (double) (FREEZE_PARTICLES_PER_SEGMENT - 1);
                double angle = start + FREEZE_SEGMENT_SPAN * t;
                double x = center.getX() + radius * Math.cos(angle);
                double z = center.getZ() + radius * Math.sin(angle);

                Particle.DustOptions color;
                if (i == 0 || i == FREEZE_PARTICLES_PER_SEGMENT - 1) {
                    color = FREEZE_HIGHLIGHT; // segment endpoints = white highlight
                } else {
                    color = pickFreezeDust(i);
                }

                float sizeMul = (float) Math.max(0.5, intensity);
                world.spawnParticle(Particle.DUST, x, y, z, 1, 0, 0, 0, 0,
                        new Particle.DustOptions(color.getColor(), (float) (color.getSize() * sizeMul)));
            }
        }
    }

    /** ~50/25/15/10 cyan/bright-blue/white/deep-frost distribution helper. */
    private Particle.DustOptions pickFreezeDust(int i) {
        int mod = Math.floorMod(i, 10);
        if (mod < 5) return FREEZE_ICE_CYAN;        // 50%
        if (mod < 8) return FREEZE_BRIGHT_BLUE;      // 30% (close to 25%, rounds fine at low counts)
        if (mod < 9) return FREEZE_DEEP_FROST;       // 10%
        return FREEZE_HIGHLIGHT;                     // 10%
    }

    /**
     * 6–8 thin vertical ice spikes around the ring. Only a rotating subset
     * is drawn each call (controlled by activeCount) to keep density low.
     */
    private void renderIceSpikes(World world, Location center, double rotation, int tick, int activeCount) {
        int maxSpikes = 8;
        double y = center.getY() + 1.0;
        int shown = Math.max(0, Math.min(maxSpikes, activeCount));
        for (int i = 0; i < shown; i++) {
            double angle = rotation + (Math.PI * 2 * i / maxSpikes);
            double x = center.getX() + FREEZE_RING_RADIUS * Math.cos(angle);
            double z = center.getZ() + FREEZE_RING_RADIUS * Math.sin(angle);
            // Small thin vertical column — 2 points, base + tip.
            world.spawnParticle(Particle.END_ROD, x, y - 0.15, z, 1, 0, 0, 0, 0);
            world.spawnParticle(Particle.DUST, x, y + 0.15, z, 1, 0, 0, 0, 0, FREEZE_ICE_CYAN);
        }
    }

    /** Sparse orbiting snowflakes — accent only, never the majority particle. */
    private void renderFreezeSnowflakes(World world, Location center, double rotation, int tick) {
        if (tick % 4 != 0) return;
        int count = 3; // spread across calls -> stays within the 8-12 sustained budget
        double y = center.getY() + 1.0 + Math.sin(tick * 0.15) * 0.15;
        for (int i = 0; i < count; i++) {
            double angle = -rotation * 0.6 + (Math.PI * 2 * i / count) + tick * 0.05;
            double radius = FREEZE_RING_RADIUS + 0.3;
            double x = center.getX() + radius * Math.cos(angle);
            double z = center.getZ() + radius * Math.sin(angle);
            world.spawnParticle(Particle.SNOWFLAKE, x, y, z, 0, 0, 0.01, 0, 0);
        }
    }

    /** 2–4 small floating ice shards that drift near the barrier, on/off. */
    private void renderIceShards(World world, Location center, double rotation, int tick) {
        int cycle = tick % 60;
        if (cycle >= 40) return; // "appear and disappear occasionally"
        int shardCount = 2 + (cycle / 20); // 2 -> 3 across the visible window
        double y = center.getY() + 1.3 + Math.sin(tick * 0.08) * 0.2;
        for (int i = 0; i < shardCount; i++) {
            double angle = rotation * 1.3 + (Math.PI * 2 * i / 4) + tick * 0.02;
            double radius = FREEZE_RING_RADIUS * 0.75;
            double x = center.getX() + radius * Math.cos(angle);
            double z = center.getZ() + radius * Math.sin(angle);
            world.spawnParticle(Particle.DUST, x, y, z, 1, 0, 0, 0, 0, FREEZE_BRIGHT_BLUE);
        }
    }

    /** Very low-density frost dust near random ring points. */
    private void renderFrostDust(World world, Location center, double rotation, int tick) {
        if (tick % 6 != 0 || random.nextInt(3) != 0) return;
        int count = 4 + random.nextInt(3); // 4-6
        double y = center.getY() + 0.9;
        for (int i = 0; i < count; i++) {
            double angle = rotation + random.nextDouble() * Math.PI * 2;
            double radius = FREEZE_RING_RADIUS * (0.85 + random.nextDouble() * 0.2);
            double x = center.getX() + radius * Math.cos(angle);
            double z = center.getZ() + radius * Math.sin(angle);
            world.spawnParticle(Particle.DUST, x, y, z, 1, 0, 0, 0, 0,
                    random.nextBoolean() ? FREEZE_ICE_CYAN : FREEZE_HIGHLIGHT);
        }
    }

    /** Full sustained loop — ring + spikes + snowflakes + shards + dust, all throttled. */
    private void renderSustainedFrost(World world, Location center, double rotation, int tick) {
        renderFrostRing(world, center, FREEZE_RING_RADIUS, rotation, 1.0);
        renderIceSpikes(world, center, rotation, tick, 7);
        renderFreezeSnowflakes(world, center, rotation, tick);
        renderIceShards(world, center, rotation, tick);
        renderFrostDust(world, center, rotation, tick);
    }

    /** Ending — ring contracts and fades, spikes shrink, small final frost burst. */
    private void renderFrostEnding(World world, Location center, double rotation, int elapsed, int totalEndTicks) {
        double progress = Math.min(1.0, elapsed / (double) Math.max(1, totalEndTicks));
        double radius = FREEZE_RING_RADIUS * (1.0 - progress) + 0.5 * progress;
        // ring keeps rotating but slower and shrinking
        renderFrostRing(world, center, Math.max(0.5, radius), rotation * 0.5, Math.max(0.3, 1.0 - progress));

        int spikeCount = (int) Math.round(8 * (1.0 - progress));
        if (spikeCount > 0) {
            renderIceSpikes(world, center, rotation * 0.5, elapsed, spikeCount);
        }

        if (elapsed == totalEndTicks - 1 || elapsed >= totalEndTicks - 1) {
            // Final small burst at the very last frame of the ending animation.
            world.spawnParticle(Particle.DUST, center.clone().add(0, 1.0, 0),
                    6, 0.15, 0.2, 0.15, 0, FREEZE_ICE_CYAN);
            world.spawnParticle(Particle.DUST, center.clone().add(0, 1.0, 0),
                    3, 0.1, 0.1, 0.1, 0, FREEZE_HIGHLIGHT);
        }
    }

    // NOTE: the old regen visuals (startRegenAura() 3-heart orbit loop and
    // the static spawnRegenPassiveParticles() burst below) have been
    // completely removed. Regen's active ability had THREE particle systems
    // running at once — this one, RegenAbilityManager's own runVisualLoop(),
    // and the one-shot burst in RegenAbilityManager.launch() — the same
    // class of dual/triple-system conflict fixed earlier for Fire. Regen's
    // active now uses ONLY VitalityParticleRenderer.start()/
    // playEndAnimation() for its visual. See RegenAbility.triggerVitalitySurge()
    // / RegenAbility.onUnequip().

    // Passive hit particles - subtle burst on 10th hit
    public static void spawnFirePassiveParticles(Location loc) {
        loc.getWorld().spawnParticle(Particle.FLAME, loc, 15, 0.4, 0.4, 0.4, 0.1);
        loc.getWorld().spawnParticle(Particle.LAVA, loc, 4, 0.3, 0.2, 0.3, 0);
        loc.getWorld().spawnParticle(Particle.SMALL_FLAME, loc, 8, 0.5, 0.3, 0.5, 0.05);
    }

    /**
     * Frost Impact — short flash + a few ice particles + a quick expanding
     * ripple, played at the point a target is successfully frozen (both
     * the passive 10th-hit stun and the active AoE freeze). Signature
     * unchanged so existing call sites don't need to change; this is a
     * pure particle-only redesign of what used to be a 18-particle
     * SNOWFLAKE/ITEM_SNOWBALL cloud.
     */
    public static void spawnFreezePassiveParticles(Location loc) {
        World world = loc.getWorld();
        if (world == null) return;

        // Small cyan/white flash
        world.spawnParticle(Particle.DUST, loc, 4, 0.1, 0.1, 0.1, 0, FREEZE_ICE_CYAN);
        world.spawnParticle(Particle.DUST, loc, 2, 0.08, 0.08, 0.08, 0, FREEZE_HIGHLIGHT);

        // A few ice particles
        world.spawnParticle(Particle.END_ROD, loc, 3, 0.15, 0.15, 0.15, 0.01);

        // Tiny circular frost ripple, 0.2 -> 0.8 blocks, expanding once.
        for (int i = 0; i < 10; i++) {
            double angle = Math.toRadians(36.0 * i);
            double radius = 0.2 + (0.6 * (i % 2)); // alternate inner/outer pass for a quick "pop"
            double x = loc.getX() + radius * Math.cos(angle);
            double z = loc.getZ() + radius * Math.sin(angle);
            world.spawnParticle(Particle.DUST, x, loc.getY(), z, 1, 0, 0, 0, 0,
                    (i % 3 == 0) ? FREEZE_HIGHLIGHT : FREEZE_BRIGHT_BLUE);
        }
    }

    public void cancelAura(UUID uuid) {
        BukkitTask task = activeTasks.remove(uuid);
        if (task != null) task.cancel();
    }

    public void cancelAll() {
        activeTasks.values().forEach(BukkitTask::cancel);
        activeTasks.clear();
    }
}
