package com.elementallegends.listeners;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.ItemStack;

/**
 * Handles clicks inside the ElementalLegends GUIs (/sword, /mace, /aura).
 * Clicking a slot always cancels the raw inventory transaction and instead
 * gives the player a fresh clone of the item, so the menu can be claimed
 * from indefinitely.
 */
public class GUIListener implements Listener {

    @EventHandler
    public void onClick(InventoryClickEvent event) {
        String title = plainTitle(event.getView().title());
        if (!title.equals("⚔ Elemental Swords ⚔")
                && !title.equals("💥 Legendary Mace GUI")
                && !title.equals("🛡 Void Armor GUI")) {
            return;
        }

        event.setCancelled(true);

        ItemStack clicked = event.getCurrentItem();
        if (clicked == null || clicked.getType().isAir()) return;
        if (!(event.getWhoClicked() instanceof Player player)) return;

        ItemStack give = clicked.clone();
        var leftover = player.getInventory().addItem(give);
        if (!leftover.isEmpty()) {
            player.sendMessage(Component.text("Your inventory is full!", NamedTextColor.RED));
            return;
        }
        player.playSound(player.getLocation(), Sound.ENTITY_ITEM_PICKUP, 1f, 1f);
    }

    private String plainTitle(Component titleComponent) {
        return net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer.plainText()
                .serialize(titleComponent);
    }
}
