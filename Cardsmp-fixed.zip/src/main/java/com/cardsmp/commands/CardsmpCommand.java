package com.cardsmp.commands;

import com.cardsmp.CardsmpPlugin;
import com.cardsmp.inventory.impl.CardsGUI;
import com.cardsmp.util.ColorUtil;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class CardsmpCommand implements CommandExecutor {

    private final CardsmpPlugin plugin;

    public CardsmpCommand(CardsmpPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("§cOnly players can use this command.");
            return true;
        }
        if (!player.hasPermission("cardsmp.gui")) {
            player.sendActionBar(ColorUtil.colorize("&cYou don't have permission to use this command."));
            return true;
        }
        CardsGUI gui = new CardsGUI(plugin);
        plugin.getGuiManager().openGUI(gui, player);
        return true;
    }
}