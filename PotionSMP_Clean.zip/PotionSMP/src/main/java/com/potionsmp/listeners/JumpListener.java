package com.potionsmp.listeners;

import com.destroystokyo.paper.event.player.PlayerJumpEvent;
import com.potionsmp.PotionSMP;
import com.potionsmp.abilities.RegenAbility;
import com.potionsmp.utils.PotionType;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;

/**
 * Detects a ground-to-ground double-jump (jump, land, jump again within a
 * short window) to launch the Regen Potion's active ability (Vitality Surge).
 *
 * This only does anything if the player has already "armed" the ability via
 * /slot1 or /slot2 (see RegenAbility.activate()) AND still has Regen equipped
 * in some slot. A normal jump with no arm state is just a normal jump.
 */
public class JumpListener implements Listener {

    private final PotionSMP plugin;

    public JumpListener(PotionSMP plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onJump(PlayerJumpEvent event) {
        Player player = event.getPlayer();

        if (!plugin.getRegenAbilityManager().isArmed(player.getUniqueId())) return;

        PotionType slot1 = plugin.getSlotManager().getSlot1(player.getUniqueId());
        PotionType slot2 = plugin.getSlotManager().getSlot2(player.getUniqueId());
        boolean regenEquipped = (slot1 == PotionType.REGEN) || (slot2 == PotionType.REGEN);
        if (!regenEquipped) {
            // Safety: shouldn't normally happen (armed state is cleared on unequip),
            // but guard against it anyway.
            plugin.getRegenAbilityManager().disarm(player.getUniqueId());
            return;
        }

        boolean isDoubleJump = plugin.getRegenAbilityManager().registerJumpAndCheckDouble(player.getUniqueId());
        if (!isDoubleJump) return; // this was just the first jump of the pair, wait for the second

        RegenAbility ability = (RegenAbility) plugin.getAbilityRegistry().get(PotionType.REGEN);
        ability.triggerVitalitySurge(plugin, player);
    }
}
