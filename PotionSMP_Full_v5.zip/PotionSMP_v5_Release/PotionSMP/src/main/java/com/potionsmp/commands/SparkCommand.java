package com.potionsmp.commands;

import com.potionsmp.PotionSMP;
import com.potionsmp.listeners.FirePotionListener;
import com.potionsmp.listeners.FreezePotionListener;
import com.potionsmp.utils.PotionUtils;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

/**
 * /lspark -> triggers Fire Potion's active ability (Inferno Rage)
 * /rspark -> triggers Freeze Potion's active ability (Arctic Prison)
 *
 * Designed to be bound to a key client-side using a "Bind Command" mod,
 * so players can trigger abilities without needing to right-click.
 * Player-only; console cannot use these (no target player context).
 */
public class SparkCommand implements CommandExecutor {

    private final PotionSMP plugin;
    private final boolean isFire; // true = /lspark (fire), false = /rspark (freeze)

    public SparkCommand(PotionSMP plugin, boolean isFire) {
        this.plugin = plugin;
        this.isFire = isFire;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage(PotionUtils.colorize("&cThis command can only be used in-game."));
            return true;
        }

        if (isFire) {
            FirePotionListener.ActivationResult result = FirePotionListener.activate(plugin, player);
            handleResult(player, result, PotionUtils.FIRE);
        } else {
            FreezePotionListener.ActivationResult result = FreezePotionListener.activate(plugin, player);
            handleResult(player, result, PotionUtils.FREEZE);
        }

        return true;
    }

    private void handleResult(Player player, Enum<?> result, String type) {
        String name = result.name();
        if (name.equals("NO_POTION")) {
            player.sendMessage(PotionUtils.msg("no-potion"));
        } else if (name.equals("ON_COOLDOWN")) {
            long rem = plugin.getCooldownManager().getRemainingSeconds(player.getUniqueId(), type);
            player.sendMessage(PotionUtils.msg("on-cooldown").replace("%seconds%", String.valueOf(rem)));
        }
        // SUCCESS case already sends its own messages inside activate()
    }
}
