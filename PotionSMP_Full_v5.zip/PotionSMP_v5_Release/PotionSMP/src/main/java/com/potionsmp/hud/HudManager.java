package com.potionsmp.hud;

import com.potionsmp.PotionSMP;
import com.potionsmp.managers.PlayerPotionManager;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.Style;
import net.kyori.adventure.key.Key;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;

/**
 * Shows a single ActionBar line (just above the XP bar) for each player,
 * combining both potion slots' status in one go, similar to InfuseSMP's
 * action-bar HUD - but with an actual graphical icon (via custom resource-pack
 * font) instead of just an emoji, followed by the Ready/cooldown text:
 *
 *   [FIRE ICON] Ready   |   [FREEZE ICON] 12s
 *
 * The icon characters (U+E000 fire, U+E001 freeze) are mapped to custom
 * textures by the "potionsmp" font defined in the resource pack
 * (assets/minecraft/font/potionsmp.json). This does NOT touch the game's
 * default font, so normal text everywhere else is unaffected.
 *
 * Only the slots the player has actually unlocked (by drinking) are shown.
 * If the player has neither potion unlocked, no action bar is sent.
 */
public class HudManager {

    // Private Use Area characters mapped in the resource pack font
    private static final String FIRE_ICON_CHAR = "\uE000";
    private static final String FREEZE_ICON_CHAR = "\uE001";

    // Must match the resource pack's font file: assets/minecraft/font/potionsmp.json
    private static final Key ICON_FONT = Key.key("minecraft", "potionsmp");

    private final PotionSMP plugin;
    private BukkitTask task;

    public HudManager(PotionSMP plugin) {
        this.plugin = plugin;
    }

    public void start() {
        task = Bukkit.getScheduler().runTaskTimer(plugin, this::tick, 0L, 10L); // every 0.5s
    }

    public void stop() {
        if (task != null) task.cancel();
    }

    private void tick() {
        PlayerPotionManager ppm = plugin.getPlayerPotionManager();

        for (Player player : Bukkit.getOnlinePlayers()) {
            boolean hasFire = ppm.isFireActive(player.getUniqueId());
            boolean hasFreeze = ppm.isFreezeActive(player.getUniqueId());

            if (!hasFire && !hasFreeze) continue; // nothing unlocked, send nothing

            Component bar = Component.empty();

            if (hasFire) {
                bar = bar.append(buildSegment(player, PotionSlot.FIRE));
            }

            if (hasFire && hasFreeze) {
                bar = bar.append(Component.text("   |   ", NamedTextColor.DARK_GRAY));
            }

            if (hasFreeze) {
                bar = bar.append(buildSegment(player, PotionSlot.FREEZE));
            }

            player.sendActionBar(bar);
        }
    }

    private enum PotionSlot { FIRE, FREEZE }

    private Component buildSegment(Player player, PotionSlot slot) {
        String type = (slot == PotionSlot.FIRE) ? "fire" : "freeze";
        boolean onCooldown = plugin.getCooldownManager().isOnCooldown(player.getUniqueId(), type);
        long remaining = plugin.getCooldownManager().getRemainingSeconds(player.getUniqueId(), type);

        String iconChar = (slot == PotionSlot.FIRE) ? FIRE_ICON_CHAR : FREEZE_ICON_CHAR;
        NamedTextColor color = (slot == PotionSlot.FIRE) ? NamedTextColor.RED : NamedTextColor.AQUA;

        // The icon glyph itself, rendered using our custom font
        Component icon = Component.text(iconChar).style(Style.style().font(ICON_FONT).build());

        // The status text right after it, using the normal default font
        Component status;
        if (onCooldown) {
            status = Component.text(" " + remaining + "s", NamedTextColor.YELLOW);
        } else {
            status = Component.text(" Ready", NamedTextColor.GREEN);
        }

        return Component.text().color(color).append(icon).append(status).build();
    }
}
