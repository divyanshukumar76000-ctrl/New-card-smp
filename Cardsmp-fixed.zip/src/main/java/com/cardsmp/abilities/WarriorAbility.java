package com.cardsmp.abilities;

import com.cardsmp.CardsmpPlugin;
import com.cardsmp.cards.CardType;
import com.cardsmp.managers.ActiveCardManager;
import com.cryptomorin.xseries.XSound;
import org.bukkit.Color;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Mob;
import org.bukkit.entity.Player;
import org.bukkit.entity.Ravager;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;

import java.util.UUID;

public class WarriorAbility {

    // 25s duration = 250 iterations at 2-tick interval
    private static final int DURATION_ITERATIONS = 250;

    public static void activate(Player owner, CardsmpPlugin plugin) {
        UUID ownerUUID = owner.getUniqueId();
        ActiveCardManager manager = plugin.getActiveCardManager();

        manager.setActiveCard(ownerUUID, CardType.WARRIOR);
        manager.setCombatTriggered(ownerUUID, false);

        // Summon ravager
        Location spawnLoc = owner.getLocation();
        Ravager ravager = (Ravager) owner.getWorld().spawnEntity(spawnLoc, EntityType.RAVAGER);
        ravager.setTarget(null);
        manager.addEntity(ownerUUID, ravager);

        // Sound
        XSound.matchXSound("ENTITY_RAVAGER_ROAR").ifPresent(s ->
            owner.getWorld().playSound(owner.getLocation(), s.get(), 2f, 1f));

        // Activation flash
        owner.getWorld().spawnParticle(Particle.DUST, owner.getLocation().add(0, 1, 0),
            30, 1.0, 1.0, 1.0, 0, new Particle.DustOptions(Color.fromRGB(200, 0, 0), 2.0f));

        int[] ticks = {0};

        BukkitTask task = new BukkitRunnable() {
            @Override
            public void run() {
                if (ravager.isDead() || !owner.isOnline() || !manager.hasActiveCard(ownerUUID)) {
                    cancel();
                    return;
                }

                ticks[0]++;

                boolean combat = manager.isCombatTriggered(ownerUUID);
                Location ravLoc = ravager.getLocation();

                // Particle effects every 2 ticks (every run)
                for (int i = 0; i < 12; i++) {
                    double angle = 2 * Math.PI * i / 12;
                    double x = Math.cos(angle) * 1.8;
                    double z = Math.sin(angle) * 1.8;
                    ravLoc.getWorld().spawnParticle(Particle.DUST,
                        ravLoc.clone().add(x, 0.15, z), 1, 0, 0, 0, 0,
                        new Particle.DustOptions(Color.fromRGB(180, 0, 0), 1.2f));
                }

                // Ground crack every 3 runs
                if (ticks[0] % 3 == 0) {
                    ravLoc.getWorld().spawnParticle(Particle.BLOCK,
                        ravLoc.clone().add(0, 0.1, 0), 8, 0.6, 0.1, 0.6, 0,
                        org.bukkit.Bukkit.createBlockData(org.bukkit.Material.GRAVEL));
                }

                // Passive: pathfind toward owner
                if (!combat) {
                    if (ravager.getLocation().distanceSquared(owner.getLocation()) > 64) {
                        ravager.getPathfinder().moveTo(owner, 1.1);
                    }
                } else {
                    // Combat: target nearest enemy every 20 runs
                    if (ticks[0] % 20 == 0) {
                        Player enemy = manager.getNearestEnemy(owner, ravLoc, 30.0);
                        if (enemy != null) ravager.setTarget(enemy);
                    }
                }

                // Duration check
                if (ticks[0] >= DURATION_ITERATIONS) {
                    manager.cleanupPlayer(ownerUUID);
                    cancel();
                }
            }
        }.runTaskTimer(plugin, 0L, 2L);

        manager.addTask(ownerUUID, task);
    }
}