package com.potionsmp.listeners;

import com.potionsmp.PotionSMP;
import com.potionsmp.abilities.Ability;
import com.potionsmp.utils.PotionType;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;

public class CombatListener implements Listener {

    private final PotionSMP plugin;

    public CombatListener(PotionSMP plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onHit(EntityDamageByEntityEvent event) {
        if (event.isCancelled()) return;
        if (!(event.getDamager() instanceof Player player)) return;
        if (!(event.getEntity() instanceof LivingEntity target)) return;

        PotionType slot1 = plugin.getSlotManager().getSlot1(player.getUniqueId());
        PotionType slot2 = plugin.getSlotManager().getSlot2(player.getUniqueId());

        if (slot1 != null) {
            Ability ability = plugin.getAbilityRegistry().get(slot1);
            if (ability != null) ability.onHit(plugin, player, target);
        }

        if (slot2 != null && slot2 != slot1) {
            Ability ability = plugin.getAbilityRegistry().get(slot2);
            if (ability != null) ability.onHit(plugin, player, target);
        }
    }
}
