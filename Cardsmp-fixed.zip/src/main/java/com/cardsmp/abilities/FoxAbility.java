package com.cardsmp.abilities;

import com.cardsmp.CardsmpPlugin;
import com.cardsmp.cards.CardType;
import com.cardsmp.managers.ActiveCardManager;
import com.cryptomorin.xseries.XSound;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class FoxAbility {

    // 20s duration = 200 iterations at 2-tick interval
    private static final int DURATION_ITERATIONS = 200;
    private static final double FREEZE_RADIUS = 15.0;

    public static void activate(Player owner, CardsmpPlugin plugin) {
        UUID ownerUUID = owner.getUniqueId();
        ActiveCardManager manager = plugin.getActiveCardManager();

        manager.setActiveCard(ownerUUID, CardType.FOX);

        Location center = owner.getLocation();

        // Freeze nearby enemies
        List<Player> frozenPlayers = new ArrayList<>();
        for (Entity entity : center.getWorld().getNearbyEntities(center, FREEZE_RADIUS, FREEZE_RADIUS, FREEZE_RADIUS)) {
            if (entity instanceof Player target && !target.getUniqueId().equals(ownerUUID)) {
                manager.freezePlayer(ownerUUID, target);
                frozenPlayers.add(target);
            }
        }

        // Activation FX
        center.getWorld().spawnParticle(Particle.SNOWFLAKE, center.clone().add(0, 1, 0), 60, 2, 2, 2, 0.05);
        center.getWorld().spawnParticle(Particle.ITEM,
            center.clone().add(0, 1, 0), 30, 1, 1, 1, 0.1,
            new org.bukkit.inventory.ItemStack(Material.ICE));

        XSound.matchXSound("BLOCK_GLASS_BREAK").ifPresent(s ->
            center.getWorld().playSound(center, s.get(), 2f, 0.5f));

        int[] ticks = {0};

        BukkitTask task = new BukkitRunnable() {
            @Override
            public void run() {
                if (!owner.isOnline() || !manager.hasActiveCard(ownerUUID)) {
                    cancel();
                    return;
                }

                ticks[0]++;

                // Snowflake aura around frozen players every run
                for (Player frozen : new ArrayList<>(frozenPlayers)) {
                    if (!frozen.isOnline() || frozen.isDead()) continue;
                    Location fLoc = frozen.getLocation().add(0, 1, 0);
                    fLoc.getWorld().spawnParticle(Particle.SNOWFLAKE, fLoc, 5, 0.4, 0.4, 0.4, 0.01);
                    fLoc.getWorld().spawnParticle(Particle.CLOUD, fLoc, 2, 0.3, 0.3, 0.3, 0);
                }

                if (ticks[0] >= DURATION_ITERATIONS) {
                    manager.cleanupPlayer(ownerUUID);
                    cancel();
                }
            }
        }.runTaskTimer(plugin, 0L, 2L);

        manager.addTask(ownerUUID, task);
    }
}