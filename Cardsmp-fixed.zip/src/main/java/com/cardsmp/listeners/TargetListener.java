package com.cardsmp.listeners;

import com.cardsmp.managers.ActiveCardManager;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityTargetLivingEntityEvent;

import java.util.UUID;

public class TargetListener implements Listener {

    private final ActiveCardManager manager;

    public TargetListener(ActiveCardManager manager) {
        this.manager = manager;
    }

    @EventHandler
    public void onEntityTarget(EntityTargetLivingEntityEvent event) {
        UUID entityUUID = event.getEntity().getUniqueId();
        if (!manager.isTrackedEntity(entityUUID)) return;

        UUID ownerUUID = manager.getEntityOwner(entityUUID);
        if (ownerUUID == null) return;

        LivingEntity target = event.getTarget();

        // ABSOLUTE RULE: never target owner
        if (target instanceof Player player && player.getUniqueId().equals(ownerUUID)) {
            event.setCancelled(true);
            return;
        }

        // Passive mode: no targeting at all
        if (!manager.isCombatTriggered(ownerUUID)) {
            event.setCancelled(true);
        }
    }
}