package com.potionsmp.hud;

import com.potionsmp.PotionSMP;
import com.potionsmp.utils.PotionType;
import net.kyori.adventure.key.Key;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.Style;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;

import java.util.EnumMap;
import java.util.Map;

/**
 * Renders a 2-slot HUD above the XP bar via ActionBar every 10 ticks.
 *
 * Font : minecraft:default  (assets/minecraft/font/default.json)
 * Chars: potionsmp:icons/effects.png sprite sheet
 *
 * Unicode layout (col 0 = normal icon, col 2 = dark/cooldown icon):
 *   \uE901 = empty slot background
 *   Row 0 → aqua      \uE001 / \uE201   (not in use yet)
 *   Row 1 → glitch    \uE002 / \uE202
 *   Row 2 → warrior   \uE003 / \uE203   (used for SHIELD)
 *   Row 3 → freeze    \uE004 / \uE204
 *   Row 4 → ender     \uE005 / \uE205
 *   Row 5 → fire      \uE006 / \uE206
 *   Row 6 → teleport  \uE007 / \uE207
 *   Row 7 → regen     \uE008 / \uE208
 *
 * New potions (Speed, Feather, Emerald, Strength, Haste) use the next
 * available rows in the effects.png sheet:
 *   Row 8  → speed    \uE009 / \uE209
 *   Row 9  → feather  \uE00A / \uE20A
 *   Row 10 → emerald  \uE00B / \uE20B
 *   Row 11 → strength \uE00C / \uE20C
 *   Row 12 → haste    \uE00D / \uE20D
 *
 * Space chars:
 *   \uE904 = +2 px   \uE905 = +6 px
 *
 * HUD always renders for ALL online players — even if both slots are empty.
 * Empty slot shows \uE901 (the dark square background from empty.png).
 *
 * Cooldown display: icon + " 45s"   (yellow)  when on cooldown
 * Ready display   : icon only        (no text)  when ready
 */
public class HudManager {

    // ── Font key ──────────────────────────────────────────────────────────
    private static final Key FONT = Key.key("minecraft", "default");

    // ── Slot background ───────────────────────────────────────────────────
    private static final String SLOT_EMPTY = "\uE901";

    // ── Space chars ───────────────────────────────────────────────────────
    private static final String SP2 = "\uE904"; // +2 px
    private static final String SP6 = "\uE905"; // +6 px

    // ── Icon record: normal char + cooldown (dark) char + label colour ────
    private record IconInfo(String normal, String dark, NamedTextColor color) {}

    private static final Map<PotionType, IconInfo> ICONS = new EnumMap<>(PotionType.class);
    static {
        // Existing potions — chars confirmed from resource pack
        ICONS.put(PotionType.FIRE,     new IconInfo("\uE006", "\uE206", NamedTextColor.RED));
        ICONS.put(PotionType.FREEZE,   new IconInfo("\uE004", "\uE204", NamedTextColor.AQUA));
        ICONS.put(PotionType.REGEN,    new IconInfo("\uE008", "\uE208", NamedTextColor.GREEN));
        ICONS.put(PotionType.GLITCH,   new IconInfo("\uE002", "\uE202", NamedTextColor.LIGHT_PURPLE));
        ICONS.put(PotionType.SHIELD,   new IconInfo("\uE003", "\uE203", NamedTextColor.WHITE));
        ICONS.put(PotionType.ENDER,    new IconInfo("\uE005", "\uE205", NamedTextColor.DARK_PURPLE));
        ICONS.put(PotionType.TELEPORT, new IconInfo("\uE007", "\uE207", NamedTextColor.DARK_AQUA));

        // New potions — rows 8–12 of effects.png
        ICONS.put(PotionType.SPEED,    new IconInfo("\uE009", "\uE209", NamedTextColor.YELLOW));
        ICONS.put(PotionType.FEATHER,  new IconInfo("\uE00A", "\uE20A", NamedTextColor.WHITE));
        ICONS.put(PotionType.EMERALD,  new IconInfo("\uE00B", "\uE20B", NamedTextColor.GREEN));
        ICONS.put(PotionType.STRENGTH, new IconInfo("\uE00C", "\uE20C", NamedTextColor.RED));
        ICONS.put(PotionType.HASTE,    new IconInfo("\uE00D", "\uE20D", NamedTextColor.GOLD));
    }

    private final PotionSMP plugin;
    private BukkitTask task;

    public HudManager(PotionSMP plugin) {
        this.plugin = plugin;
    }

    // ── Lifecycle ─────────────────────────────────────────────────────────

    public void start() {
        task = Bukkit.getScheduler().runTaskTimer(plugin, this::tick, 0L, 10L);
    }

    public void stop() {
        if (task != null) { task.cancel(); task = null; }
    }

    // ── Tick: send to ALL online players, always ──────────────────────────

    private void tick() {
        for (Player player : Bukkit.getOnlinePlayers()) {
            player.sendActionBar(buildHUD(player));
        }
    }

    /**
     * Instant one-shot update for a single player (used by /swap command).
     */
    public void sendOnce(Player player) {
        player.sendActionBar(buildHUD(player));
    }

    // ── HUD builder ───────────────────────────────────────────────────────

    /**
     * Always renders:  [Slot1]  SP6  [Slot2]
     * Both slots are shown regardless of whether they are empty.
     */
    private Component buildHUD(Player player) {
        PotionType slot1 = plugin.getSlotManager().getSlot1(player.getUniqueId());
        PotionType slot2 = plugin.getSlotManager().getSlot2(player.getUniqueId());

        Style font = Style.style().font(FONT).build();

        return Component.empty()
                .append(buildSlot(player, slot1, font))
                .append(Component.text(SP6).style(font))  // gap between slots
                .append(buildSlot(player, slot2, font));
    }

    /**
     * Builds a single slot component:
     *   null type  → empty background (\uE901)
     *   ready      → normal icon, no text
     *   cooldown   → dark icon + yellow " 45s" suffix
     */
    private Component buildSlot(Player player, PotionType type, Style fontStyle) {
        if (type == null) {
            return Component.text(SLOT_EMPTY + SP2).style(fontStyle);
        }

        IconInfo info = ICONS.getOrDefault(type,
            new IconInfo(SLOT_EMPTY, SLOT_EMPTY, NamedTextColor.WHITE));

        boolean onCooldown = plugin.getCooldownManager()
                .isOnCooldown(player.getUniqueId(), type);

        if (onCooldown) {
            long secs = plugin.getCooldownManager()
                    .getRemainingSeconds(player.getUniqueId(), type);
            // Dark icon + cooldown seconds — no "Ready" text ever shown
            return Component.empty()
                    .append(Component.text(info.dark() + SP2)
                            .style(fontStyle)
                            .color(info.color()))
                    .append(Component.text(secs + "s", NamedTextColor.YELLOW));
        }

        // Ready: just the normal icon, no text
        return Component.text(info.normal() + SP2)
                .style(fontStyle)
                .color(info.color());
    }
}
