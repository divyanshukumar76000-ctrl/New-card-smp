package com.elementallegends;

import com.elementallegends.commands.MenuCommands;
import com.elementallegends.listeners.AbilityListener;
import com.elementallegends.listeners.GUIListener;
import com.elementallegends.managers.AbilityManager;
import com.elementallegends.managers.CooldownManager;
import com.elementallegends.managers.PassiveManager;
import com.elementallegends.util.ItemKeys;
import org.bukkit.plugin.java.JavaPlugin;

public class ElementalLegends extends JavaPlugin {

    private CooldownManager cooldownManager;
    private AbilityManager abilityManager;
    private PassiveManager passiveManager;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        ItemKeys.init(this);

        cooldownManager = new CooldownManager(this);
        abilityManager = new AbilityManager(this);
        passiveManager = new PassiveManager(this);

        getServer().getPluginManager().registerEvents(new AbilityListener(this, cooldownManager, abilityManager), this);
        getServer().getPluginManager().registerEvents(new GUIListener(), this);

        MenuCommands menuCommands = new MenuCommands(this);
        getCommand("sword").setExecutor(menuCommands);
        getCommand("mace").setExecutor(menuCommands);
        getCommand("aura").setExecutor(menuCommands);
        getCommand("elementallegends").setExecutor(menuCommands);

        passiveManager.start();

        getLogger().info("ElementalLegends has been enabled. No console errors, ready for battle.");
    }

    @Override
    public void onDisable() {
        getLogger().info("ElementalLegends has been disabled.");
    }

    public CooldownManager getCooldownManager() {
        return cooldownManager;
    }

    public AbilityManager getAbilityManager() {
        return abilityManager;
    }
}
