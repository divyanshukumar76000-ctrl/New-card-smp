package com.potionsmp.managers;

import com.potionsmp.PotionSMP;
import org.bukkit.Color;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.HashMap;
import java.util.Map;
import java.util.Random;
import java.util.UUID;

/**
 * Shield Potion — Divine Barrier Visual Manager
 *
 * VISUAL ONLY.
 *
 * Features:
 * - 3-layer celestial shield
 * - 4 segmented outer arcs
 * - Opposite ring rotations
 * - Cyan / blue / white energy
 * - Shield fragments
 * - Activation expansion
 * - Sustained rotation
 * - Impact ripple
 * - End collapse
 *
 * IMPORTANT:
 * This class is intended to control PARTICLE VISUALS ONLY.
 * Do not put gameplay/damage/cooldown logic here.
 */
public class ShieldAuraManager {

    private final PotionSMP plugin;

    private final Map<UUID, BukkitRunnable> activeEffects = new HashMap<>();

    private final Random random = new Random();

    // ============================================================
    // VISUAL CONFIG
    // ============================================================

    // Outer barrier
    private static final double OUTER_RADIUS = 3.5;

    // Middle barrier
    private static final double MIDDLE_RADIUS = 2.5;

    // Inner barrier
    private static final double INNER_RADIUS = 1.35;

    // Heights relative to player's feet
    private static final double OUTER_Y = 1.45;
    private static final double MIDDLE_Y = 1.10;
    private static final double INNER_Y = 1.25;

    // 4 × 90° sections
    private static final int ARC_COUNT = 4;

    // Leave intentional gaps
    private static final double ARC_SPAN = 76.0;

    // Particle points per arc
    private static final int OUTER_POINTS = 8;
    private static final int MIDDLE_POINTS = 6;
    private static final int INNER_POINTS = 5;

    // Draw every 2 ticks
    private static final int DRAW_INTERVAL = 2;

    // Activation
    private static final int ACTIVATION_TICKS = 12;

    // Ending animation
    private static final int END_TICKS = 10;

    // ============================================================
    // COLORS
    // ============================================================

    private static final Particle.DustOptions CYAN =
            new Particle.DustOptions(
                    Color.fromRGB(40, 220, 255),
                    0.65f
            );

    private static final Particle.DustOptions LIGHT_BLUE =
            new Particle.DustOptions(
                    Color.fromRGB(110, 220, 255),
                    0.55f
            );

    private static final Particle.DustOptions DEEP_BLUE =
            new Particle.DustOptions(
                    Color.fromRGB(35, 100, 220),
                    0.50f
            );

    private static final Particle.DustOptions WHITE =
            new Particle.DustOptions(
                    Color.fromRGB(235, 250, 255),
                    0.75f
            );

    public ShieldAuraManager(PotionSMP plugin) {
        this.plugin = plugin;
    }

    // ============================================================
    // DIVINE BARRIER
    // ============================================================

    /**
     * Starts ONLY the visual effect.
     *
     * Gameplay duration should be supplied by the existing
     * Shield Potion logic.
     */
    public void startDivineBarrier(Player player, int durationTicks) {

        UUID uuid = player.getUniqueId();

        stopDivineBarrier(uuid);

        BukkitRunnable task = new BukkitRunnable() {

            private int ticks = 0;

            private double outerRotation =
                    random.nextDouble() * 360.0;

            private double middleRotation =
                    random.nextDouble() * 360.0;

            private double innerRotation =
                    random.nextDouble() * 360.0;

            @Override
            public void run() {

                if (!player.isOnline()) {
                    stopInternal(uuid);
                    cancel();
                    return;
                }

                if (ticks >= durationTicks) {

                    playEnding(player);

                    stopInternal(uuid);
                    cancel();

                    return;
                }

                Location center = player.getLocation();
                World world = center.getWorld();

                if (world == null) {
                    stopInternal(uuid);
                    cancel();
                    return;
                }

                // --------------------------------------------------------
                // ROTATION
                // --------------------------------------------------------

                // Outer = clockwise
                outerRotation += 2.4;

                // Middle = opposite direction
                middleRotation -= 4.0;

                // Inner = slow stable rotation
                innerRotation += 1.2;

                if (outerRotation >= 360.0) {
                    outerRotation -= 360.0;
                }

                if (middleRotation <= -360.0) {
                    middleRotation += 360.0;
                }

                if (innerRotation >= 360.0) {
                    innerRotation -= 360.0;
                }

                // --------------------------------------------------------
                // ACTIVATION
                // --------------------------------------------------------

                if (ticks < ACTIVATION_TICKS) {

                    double progress =
                            (ticks + 1) /
                            (double) ACTIVATION_TICKS;

                    double eased =
                            1.0 - Math.pow(1.0 - progress, 3.0);

                    drawActivation(
                            world,
                            center,
                            eased,
                            outerRotation,
                            middleRotation
                    );

                    ticks++;
                    return;
                }

                // --------------------------------------------------------
                // SUSTAINED VISUAL
                // --------------------------------------------------------

                if (ticks % DRAW_INTERVAL == 0) {

                    drawOuterBarrier(
                            world,
                            center,
                            outerRotation
                    );

                    drawMiddleBarrier(
                            world,
                            center,
                            middleRotation
                    );

                    drawInnerBarrier(
                            world,
                            center,
                            innerRotation
                    );

                    drawShieldFragments(
                            world,
                            center,
                            outerRotation,
                            middleRotation
                    );

                    drawCoreEnergy(
                            world,
                            center,
                            innerRotation
                    );
                }

                // --------------------------------------------------------
                // OCCASIONAL DIVINE SPARK
                // --------------------------------------------------------

                if (random.nextInt(10) == 0) {

                    spawnDivineSpark(
                            world,
                            center,
                            outerRotation
                    );
                }

                ticks++;
            }
        };

        activeEffects.put(uuid, task);

        task.runTaskTimer(
                plugin,
                0L,
                1L
        );
    }

    // ============================================================
    // ACTIVATION
    // ============================================================

    private void drawActivation(
            World world,
            Location center,
            double progress,
            double outerRotation,
            double middleRotation
    ) {

        double outerRadius =
                0.7 + (OUTER_RADIUS - 0.7) * progress;

        double middleRadius =
                0.5 + (MIDDLE_RADIUS - 0.5) * progress;

        double innerRadius =
                0.35 + (INNER_RADIUS - 0.35) * progress;

        // Energy rising from feet
        for (int i = 0; i < 5; i++) {

            double angle =
                    Math.toRadians(
                            outerRotation + i * 72.0
                    );

            double x =
                    center.getX()
                            + outerRadius * Math.cos(angle);

            double z =
                    center.getZ()
                            + outerRadius * Math.sin(angle);

            double y =
                    center.getY()
                            + 0.15
                            + progress * 1.2;

            world.spawnParticle(
                    Particle.DUST,
                    x,
                    y,
                    z,
                    1,
                    CYAN
            );
        }

        // Expanding outer ring
        drawSegmentedRing(
                world,
                center,
                outerRadius,
                center.getY() + OUTER_Y,
                outerRotation,
                OUTER_POINTS,
                CYAN,
                1.0
        );

        // Expanding middle ring
        drawSegmentedRing(
                world,
                center,
                middleRadius,
                center.getY() + MIDDLE_Y,
                middleRotation,
                MIDDLE_POINTS,
                LIGHT_BLUE,
                0.75
        );

        // Core energy
        drawSegmentedRing(
                world,
                center,
                innerRadius,
                center.getY() + INNER_Y,
                outerRotation * 0.5,
                INNER_POINTS,
                WHITE,
                0.55
        );
    }

    // ============================================================
    // OUTER BARRIER
    // ============================================================

    private void drawOuterBarrier(
            World world,
            Location center,
            double rotation
    ) {

        drawSegmentedRing(
                world,
                center,
                OUTER_RADIUS,
                center.getY() + OUTER_Y,
                rotation,
                OUTER_POINTS,
                CYAN,
                1.0
        );

        // White highlight points
        for (int arc = 0; arc < ARC_COUNT; arc++) {

            if (random.nextInt(3) != 0) {
                continue;
            }

            double angle =
                    Math.toRadians(
                            rotation
                                    + arc * 90.0
                                    + 38.0
                    );

            spawnDust(
                    world,
                    center,
                    OUTER_RADIUS,
                    center.getY() + OUTER_Y + 0.02,
                    angle,
                    WHITE
            );
        }
    }

    // ============================================================
    // MIDDLE BARRIER
    // ============================================================

    private void drawMiddleBarrier(
            World world,
            Location center,
            double rotation
    ) {

        drawSegmentedRing(
                world,
                center,
                MIDDLE_RADIUS,
                center.getY() + MIDDLE_Y,
                rotation,
                MIDDLE_POINTS,
                LIGHT_BLUE,
                0.80
        );

        // Small deep-blue energy accents
        if (random.nextInt(3) == 0) {

            double angle =
                    Math.toRadians(
                            rotation
                                    + random.nextDouble() * 360.0
                    );

            spawnDust(
                    world,
                    center,
                    MIDDLE_RADIUS,
                    center.getY() + MIDDLE_Y,
                    angle,
                    DEEP_BLUE
            );
        }
    }

    // ============================================================
    // INNER BARRIER
    // ============================================================

    private void drawInnerBarrier(
            World world,
            Location center,
            double rotation
    ) {

        drawSegmentedRing(
                world,
                center,
                INNER_RADIUS,
                center.getY() + INNER_Y,
                rotation,
                INNER_POINTS,
                WHITE,
                0.55
        );
    }

    // ============================================================
    // SEGMENTED RING
    // ============================================================

    private void drawSegmentedRing(
            World world,
            Location center,
            double radius,
            double y,
            double rotation,
            int points,
            Particle.DustOptions dust,
            double density
    ) {

        double gapPadding =
                (90.0 - ARC_SPAN) / 2.0;

        for (int arc = 0; arc < ARC_COUNT; arc++) {

            double start =
                    rotation
                            + arc * 90.0
                            + gapPadding;

            for (int i = 0; i < points; i++) {

                if (random.nextDouble() > density) {
                    continue;
                }

                double fraction =
                        i / (double) (points - 1);

                double angleDeg =
                        start + ARC_SPAN * fraction;

                double angle =
                        Math.toRadians(angleDeg);

                // Slight organic movement
                double wave =
                        Math.sin(
                                angle * 4.0
                                        + rotation * 0.04
                        ) * 0.035;

                double finalRadius =
                        radius + wave;

                double x =
                        center.getX()
                                + finalRadius
                                * Math.cos(angle);

                double z =
                        center.getZ()
                                + finalRadius
                                * Math.sin(angle);

                world.spawnParticle(
                        Particle.DUST,
                        x,
                        y,
                        z,
                        1,
                        dust
                );

                // Small white highlight
                if (i == 0 || i == points - 1) {

                    if (random.nextBoolean()) {

                        world.spawnParticle(
                                Particle.END_ROD,
                                x,
                                y + 0.03,
                                z,
                                1,
                                0,
                                0,
                                0,
                                0
                        );
                    }
                }
            }
        }
    }

    // ============================================================
    // SHIELD FRAGMENTS
    // ============================================================

    private void drawShieldFragments(
            World world,
            Location center,
            double outerRotation,
            double middleRotation
    ) {

        int fragmentCount = 6;

        for (int i = 0; i < fragmentCount; i++) {

            double angle =
                    Math.toRadians(
                            outerRotation
                                    + i * (360.0 / fragmentCount)
                    );

            double radius =
                    3.05
                            + 0.12
                            * Math.sin(
                            (outerRotation + i * 50.0)
                                    * 0.03
                    );

            double x =
                    center.getX()
                            + radius * Math.cos(angle);

            double z =
                    center.getZ()
                            + radius * Math.sin(angle);

            double bob =
                    Math.sin(
                            (outerRotation + i * 45.0)
                                    * 0.05
                    ) * 0.12;

            double y =
                    center.getY()
                            + 1.45
                            + bob;

            Particle.DustOptions color =
                    i % 3 == 0
                            ? WHITE
                            : CYAN;

            world.spawnParticle(
                    Particle.DUST,
                    x,
                    y,
                    z,
                    1,
                    color
            );

            if (i % 2 == 0) {

                world.spawnParticle(
                        Particle.END_ROD,
                        x,
                        y,
                        z,
                        1,
                        0,
                        0,
                        0,
                        0
                );
            }
        }

        // 2 smaller inner fragments
        for (int i = 0; i < 2; i++) {

            double angle =
                    Math.toRadians(
                            middleRotation
                                    + i * 180.0
                    );

            double x =
                    center.getX()
                            + 1.8 * Math.cos(angle);

            double z =
                    center.getZ()
                            + 1.8 * Math.sin(angle);

            world.spawnParticle(
                    Particle.DUST,
                    x,
                    center.getY() + 1.15,
                    z,
                    1,
                    LIGHT_BLUE
            );
        }
    }

    // ============================================================
    // CORE ENERGY
    // ============================================================

    private void drawCoreEnergy(
            World world,
            Location center,
            double rotation
    ) {

        double angle =
                Math.toRadians(rotation);

        double x =
                center.getX()
                        + 0.9 * Math.cos(angle);

        double z =
                center.getZ()
                        + 0.9 * Math.sin(angle);

        double y =
                center.getY()
                        + 1.25
                        + Math.sin(
                        rotation * 0.04
                ) * 0.08;

        world.spawnParticle(
                Particle.DUST,
                x,
                y,
                z,
                1,
                WHITE
        );

        if (random.nextInt(4) == 0) {

            world.spawnParticle(
                    Particle.END_ROD,
                    x,
                    y,
                    z,
                    1,
                    0,
                    0.01,
                    0,
                    0
            );
        }
    }

    // ============================================================
    // DIVINE SPARK
    // ============================================================

    private void spawnDivineSpark(
            World world,
            Location center,
            double rotation
    ) {

        double angle =
                Math.toRadians(
                        rotation
                                + random.nextDouble() * 360.0
                );

        double radius =
                OUTER_RADIUS + 0.2;

        double x =
                center.getX()
                        + radius * Math.cos(angle);

        double z =
                center.getZ()
                        + radius * Math.sin(angle);

        double y =
                center.getY()
                        + OUTER_Y
                        + random.nextDouble() * 0.4;

        world.spawnParticle(
                Particle.END_ROD,
                x,
                y,
                z,
                1,
                0,
                0,
                0,
                0
        );

        world.spawnParticle(
                Particle.DUST,
                x,
                y,
                z,
                1,
                WHITE
        );
    }

    // ============================================================
    // IMPACT RIPPLE
    // ============================================================

    /**
     * Called externally (from ShieldManager's existing hit-block logic)
     * when a hit is absorbed, to ripple the barrier outward once.
     * Visual only — no damage/knockback logic lives here.
     */
    public void spawnImpactRipple(Player player) {

        Location center = player.getLocation();
        World world = center.getWorld();

        if (world == null) {
            return;
        }

        for (int i = 0; i < 20; i++) {

            double angle =
                    Math.toRadians(18.0 * i);

            double x =
                    center.getX()
                            + OUTER_RADIUS * Math.cos(angle);

            double z =
                    center.getZ()
                            + OUTER_RADIUS * Math.sin(angle);

            world.spawnParticle(
                    Particle.DUST,
                    x,
                    center.getY() + OUTER_Y,
                    z,
                    1,
                    WHITE
            );
        }

        world.spawnParticle(
                Particle.END_ROD,
                center.clone().add(0, OUTER_Y, 0),
                14,
                0.4,
                0.4,
                0.4,
                0.05
        );
    }

    // ============================================================
    // END COLLAPSE
    // ============================================================

    private void playEnding(Player player) {

        Location center = player.getLocation();
        World world = center.getWorld();

        if (world == null) {
            return;
        }

        // All three rings collapse inward toward the core while fading.
        for (int step = 0; step < END_TICKS; step++) {

            double progress =
                    step / (double) (END_TICKS - 1);

            double fade =
                    1.0 - progress;

            double outerRadius =
                    OUTER_RADIUS * fade;

            double middleRadius =
                    MIDDLE_RADIUS * fade;

            double angleBase =
                    step * 24.0;

            for (int i = 0; i < 10; i++) {

                double angle =
                        Math.toRadians(
                                angleBase + i * 36.0
                        );

                double ox =
                        center.getX()
                                + outerRadius * Math.cos(angle);

                double oz =
                        center.getZ()
                                + outerRadius * Math.sin(angle);

                world.spawnParticle(
                        Particle.DUST,
                        ox,
                        center.getY() + OUTER_Y,
                        oz,
                        1,
                        CYAN
                );

                double mx =
                        center.getX()
                                + middleRadius * Math.cos(-angle);

                double mz =
                        center.getZ()
                                + middleRadius * Math.sin(-angle);

                world.spawnParticle(
                        Particle.DUST,
                        mx,
                        center.getY() + MIDDLE_Y,
                        mz,
                        1,
                        LIGHT_BLUE
                );
            }
        }

        // Final flash + fade at the core.
        world.spawnParticle(
                Particle.END_ROD,
                center.clone().add(0, INNER_Y, 0),
                24,
                0.3,
                0.6,
                0.3,
                0.05
        );

        world.spawnParticle(
                Particle.DUST,
                center.clone().add(0, INNER_Y, 0),
                20,
                0.25,
                0.5,
                0.25,
                0,
                WHITE
        );

        world.playSound(center, Sound.BLOCK_BEACON_DEACTIVATE, 1.0f, 1.6f);
    }

    // ============================================================
    // HELPERS
    // ============================================================

    private void spawnDust(
            World world,
            Location center,
            double radius,
            double y,
            double angle,
            Particle.DustOptions dust
    ) {

        double x =
                center.getX()
                        + radius * Math.cos(angle);

        double z =
                center.getZ()
                        + radius * Math.sin(angle);

        world.spawnParticle(
                Particle.DUST,
                x,
                y,
                z,
                1,
                dust
        );
    }

    private void stopInternal(UUID uuid) {
        activeEffects.remove(uuid);
    }

    // ============================================================
    // CONTROL
    // ============================================================

    /**
     * Stops the visual effect immediately (no ending animation — used for
     * cleanup on logout/plugin disable). For a normal end-of-duration stop,
     * the running task calls {@link #playEnding(Player)} itself.
     */
    public void stopDivineBarrier(UUID uuid) {
        BukkitRunnable task = activeEffects.remove(uuid);
        if (task != null) {
            task.cancel();
        }
    }

    public void cancelAll() {
        for (BukkitRunnable task : activeEffects.values()) {
            task.cancel();
        }
        activeEffects.clear();
    }
}
