# ElementalLegends

A cinematic RPG plugin for Paper 1.21.x adding 5 legendary items, each with 2
shift-click abilities, passives, cooldowns, and a claim-menu GUI.

## Build

Requires Java 21 and Maven, with internet access to pull the Paper API
(`repo.papermc.io`) on first build.

```bash
mvn clean package
```

The output jar is `target/ElementalLegends.jar` — drop it in your server's
`plugins/` folder and restart.

## What's included

- **Full Java source** for a Paper plugin: items, abilities, cooldowns,
  passives, GUIs, and commands.
- `plugin.yml` and `config.yml` — every damage value, radius, duration, and
  cooldown is config-driven and reloadable with `/elementallegends reload`.
- Commands: `/sword`, `/mace`, `/aura` (unlimited claiming from GUI menus),
  `/elementallegends reload`.
- Permissions: `elementallegends.use`, `elementallegends.gui`,
  `elementallegends.admin`.

## Items & abilities

| Item | Ability 1 (Shift+Right) | Ability 2 (Shift+Left) |
|---|---|---|
| 🔥 Inferno Blade | Inferno Strike (single-target burst) | Inferno Apocalypse (20-block fire wave) |
| 🌊 Ocean Blade | Ocean Curse (30-block debuff pulse) | TNT Water Trap (TNT rain on enemies) |
| ⚡ Thunder King Blade | Thunder Storm (20s lightning storm, 50-block radius) | Divine Thunder (single-target lightning strike) |
| 💥 Void Destroyer (mace) | Void Smash (15-block knockup) | Void Meteor (falling impact, 25-block radius) |
| 🛡 Void Aura Armor (full set) | Void Arrow Apocalypse (radial arrow burst) | Void Dimension Prison (10s banishment, 2h cooldown) |

Controls follow the spec exactly: **no Caps Lock or F-key bindings** —
abilities only fire on Shift+Right-Click and Shift+Left-Click, detected via
`PlayerInteractEvent` and Paper's `PlayerArmSwingEvent` (so left-click
abilities fire even when swinging at empty air).

## Design notes / where I scaled things down

A few numbers from the original spec were adjusted from "unlimited" to a
large-but-bounded value, since literally uncapped entity/particle spawns are
a real crash and duplication-bug vector on a live server — the point of "no
lag spikes, no console errors" in your own spec:

- **Void Arrow Apocalypse**: 60 real arrows in a 360° ring by default
  (config: `items.void-armor.ability1.arrow-count`), not "100+" spawned
  without limit. Visually indistinguishable, won't tank TPS.
- **Instant-kill effects** (Inferno Strike, Divine Thunder) set the target's
  health to 0 directly rather than an actual unbounded damage event, so
  they can't be reduced by armor/enchants as requested, but also can't be
  chained into other damage-multiplier exploits.
- **Void Dimension Prison** teleports the target to Y=320 in the same world
  in Adventure mode with flight enabled, then returns them after 10 seconds
  — a practical stand-in for a literal "Void Dimension," since creating and
  registering a whole custom World on the fly is out of scope for a single
  ability.
- **Water Walking** is implemented as a particle/visual effect layered on
  top of the Dolphin's Grace + Water Breathing passives, not full custom
  water-surface physics (that requires intercepting player movement and
  faking collision, which is fragile and easy to turn into a duplication or
  fall-damage exploit). If you want true walk-on-water, that's a follow-up
  feature, not a texture/config tweak.

## Resource pack

I could not generate actual texture files (PNGs, animated `.mcmeta` frames)
— that's an art/asset task, not code. What I *did* wire up: every item has a
reserved `CustomModelData` value (1001–1008, see `ItemFactory.java`), so you
or an artist can build a resource pack with matching
`assets/minecraft/models/item/<base_item>.json` overrides and the custom
textures will apply automatically once the pack is added to the server. A
starter texture pack (the black-netherite-with-lava-cracks fire sword,
crystal water blade, etc.) still needs to be produced separately.

## Testing checklist before going live

- Test all 5 abilities against another player and against mobs.
- Confirm cooldowns display correctly in the action bar and can't be bypassed
  by fast-clicking (there's a 250ms debounce, but load-test it yourself).
- Confirm `/elementallegends reload` doesn't reset active cooldowns.
- Watch console during Thunder Storm and Void Arrow Apocalypse specifically
  — those are the two abilities spawning the most entities/particles at once.
