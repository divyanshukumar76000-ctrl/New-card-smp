# 🧪 PotionSMP Plugin v3

Fire 🔥 and Freeze ❄️ ability system for PaperMC / Spigot 1.21.1 (Java 21).

## ✅ What's new in v3

1. **Both potions stack.** Drinking Fire Potion unlocks Fire abilities permanently;
   drinking Freeze Potion unlocks Freeze abilities permanently. A player can have
   BOTH unlocked at the same time — they don't override each other anymore.
2. **Independent passives.** Each type tracks its own hit-counter, so both 10-hit
   passive triggers (ignite / freeze) can fire independently while fighting.
3. **Command-based activation — `/lspark` and `/rspark`.**
   - `/lspark` → triggers Fire Potion's active ability (Inferno Rage)
   - `/rspark` → triggers Freeze Potion's active ability (Arctic Prison)
   - No right-click needed anymore. This is meant to be bound to a key using a
     client-side "Bind Command" mod, so players can fire abilities with one keypress.
   - Player-only (console can't run these — there's no "active player" context).
4. **ActionBar HUD with graphical icons** (instead of plain text/emoji). A single line
   just above the XP bar, combining both unlocked abilities' status, using your actual
   custom icon images (the ice-shield and flame-shield art) rendered inline via a
   resource-pack custom font:

   ```
   [🧊-icon] Ready    |    [🔥-icon] 12s
   ```

   - Icons come from `assets/minecraft/font/potionsmp.json` in the texture pack — a
     separate custom font namespace, so it does NOT affect any other text in the game.
   - Without the resource pack installed, the icon characters won't render as images
     (they'll show as blank/tofu boxes) — the resource pack is required for this HUD
     to look right. Status text (Ready / Xs) still always shows even without the pack.
   - Only shows the slot(s) the player has actually unlocked.
   - If neither is unlocked, nothing is shown.
   - Updates twice a second.

---

## 📦 Building the Plugin

```bash
cd PotionSMP
mvn clean package
```

Output: `target/PotionSMP.jar` → drop into `plugins/`.

---

## 🎮 Commands

| Command | Description |
|---|---|
| `/potionSMP` | Open potion GUI (pick Fire or Freeze) |
| `/potionSMP give fire [player]` | Give Fire Potion (op only) |
| `/potionSMP give freeze [player]` | Give Freeze Potion (op only) |
| `/lspark` | Trigger Inferno Rage (Fire active ability) — player only |
| `/rspark` | Trigger Arctic Prison (Freeze active ability) — player only |

Aliases for `/potionSMP`: `/psmp`, `/potion`

### Binding to a key
Install a "Bind Command" client mod, then bind:
- a key to run `/lspark` (Fire ability)
- another key to run `/rspark` (Freeze ability)

---

## 🔥 Fire Potion — Inferno Rage

| | |
|---|---|
| **Item look** | Vanilla Fire Resistance potion base + custom resource-pack icon (CustomModelData 101) |
| **Unlock** | Drink the potion once — Fire abilities stay unlocked permanently |
| **Passive** | Every 10 hits: ignites target + nearby enemies (3-block radius) |
| **Active** | `/lspark` → 5×5 (radius 2) damage **aura** around you — no fire blocks, just particles + damage/ignite tick every second to anyone standing in it. Fire trail particles follow your movement. You get Fire Resistance for the duration. |
| **Duration** | 10 seconds |
| **Cooldown** | 30 seconds |

## ❄️ Freeze Potion — Arctic Prison

| | |
|---|---|
| **Item look** | Vanilla Swiftness potion base + custom resource-pack icon (CustomModelData 102) |
| **Unlock** | Drink the potion once — Freeze abilities stay unlocked permanently |
| **Passive** | Every 10 hits: 1 extra heart damage + brief freeze (2s) on target |
| **Active** | `/rspark` → 10-block radius freeze blast. All enemies in range locked in place (can't move/attack/use abilities/throw pearls) for 3 seconds, with Slowness + Mining Fatigue. Ice particle aura. |
| **Duration** | 3 seconds freeze |
| **Cooldown** | 45 seconds |

---

## ⚙️ config.yml

All durations, radii, cooldowns, hit thresholds, and chat messages are configurable in
`plugins/PotionSMP/config.yml`.

---

## 🔗 About the Texture Pack

Potions carry `CustomModelData` (101 Fire / 102 Freeze) on top of their vanilla base type.
Without the resource pack they still look distinct (vanilla Fire Resistance vs Swiftness
colors). With the pack (`PotionSMP_TexturePack.zip`), the bottles show your custom icons.

---

## 📋 Permissions

| Permission | Default | Description |
|---|---|---|
| `potionsmp.use` | true (everyone) | Open GUI, use potions, use /lspark, /rspark |
| `potionsmp.give` | op only | Give potions to players |
