package com.potionsmp.listeners;

import com.potionsmp.PotionSMP;
import com.potionsmp.utils.PotionUtils;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerItemConsumeEvent;

public class DrinkListener implements Listener {

    private final PotionSMP plugin;

    public DrinkListener(PotionSMP plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onConsume(PlayerItemConsumeEvent event) {
        String type = PotionUtils.getPotionType(event.getItem());
        if (type == null) return; // not a PotionSMP potion, ignore

        Player player = event.getPlayer();

        // Permanently unlock this potion's abilities. Both fire and freeze
        // can be unlocked independently and stay active at the same time.
        if (PotionUtils.FIRE.equals(type)) {
            plugin.getPlayerPotionManager().unlockFire(player.getUniqueId());
            plugin.getHitCounterManager().resetFire(player.getUniqueId());
            player.sendMessage(PotionUtils.msg("drank-fire"));
        } else if (PotionUtils.FREEZE.equals(type)) {
            plugin.getPlayerPotionManager().unlockFreeze(player.getUniqueId());
            plugin.getHitCounterManager().resetFreeze(player.getUniqueId());
            player.sendMessage(PotionUtils.msg("drank-freeze"));
        }
    }
}
