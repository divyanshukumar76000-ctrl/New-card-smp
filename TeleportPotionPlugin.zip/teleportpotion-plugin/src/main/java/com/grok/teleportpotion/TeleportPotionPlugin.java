package com.grok.teleportpotion;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Color;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.PotionMeta;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.potion.PotionType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class TeleportPotionPlugin extends JavaPlugin implements Listener {

    private final Map<UUID, Integer> hitCounter = new HashMap<>();
    private final Map<UUID, Long> activeCooldown = new HashMap<>();

    @Override
    public void onEnable() {
        getServer().getPluginManager().registerEvents(this, this);
        getLogger().info("TeleportPotion Plugin enabled!");
    }

    @Override
    public void onDisable() {
        getLogger().info("TeleportPotion Plugin disabled!");
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (command.getName().equalsIgnoreCase("teleportpotion")) {
            Player target;
            if (args.length > 0) {
                target = Bukkit.getPlayer(args[0]);
                if (target == null) {
                    sender.sendMessage(ChatColor.RED + "Player not found!");
                    return true;
                }
            } else if (sender instanceof Player) {
                target = (Player) sender;
            } else {
                sender.sendMessage(ChatColor.RED + "Specify a player!");
                return true;
            }

            target.getInventory().addItem(createTeleportPotion());
            sender.sendMessage(ChatColor.GREEN + "Given Teleport Potion to " + target.getName());
            return true;
        }
        return false;
    }

    private ItemStack createTeleportPotion() {
        ItemStack potion = new ItemStack(Material.POTION);
        PotionMeta meta = (PotionMeta) potion.getItemMeta();

        meta.setDisplayName(ChatColor.LIGHT_PURPLE + "§k🌀§r Teleport Potion");
        meta.setColor(Color.PURPLE);
        meta.addEnchant(org.bukkit.enchantments.Enchantment.LUCK, 1, true); // For glow
        meta.addItemFlags(ItemFlag.HIDE_ENCHANTS, ItemFlag.HIDE_POTION_EFFECTS);

        // No actual potion effect
        meta.clearCustomPotionEffects();

        potion.setItemMeta(meta);
        return potion;
    }

    @EventHandler
    public void onPlayerInteract(PlayerInteractEvent event) {
        Player player = event.getPlayer();
        ItemStack item = event.getItem();

        if (item == null || item.getType() != Material.POTION) return;

        ItemMeta meta = item.getItemMeta();
        if (meta == null || !meta.getDisplayName().equals(ChatColor.LIGHT_PURPLE + "§k🌀§r Teleport Potion")) return;

        if (event.getAction().isRightClick()) {
            long currentTime = System.currentTimeMillis();
            UUID uuid = player.getUniqueId();
            long cooldownTime = activeCooldown.getOrDefault(uuid, 0L);

            if (currentTime - cooldownTime < 45000) { // 45 seconds
                long remaining = (45000 - (currentTime - cooldownTime)) / 1000;
                player.sendMessage(ChatColor.RED + "Cooldown: " + remaining + " seconds left!");
                return;
            }

            // Active Ability: Dimensional Shift
            performDimensionalShift(player);

            // Consume potion
            if (item.getAmount() > 1) {
                item.setAmount(item.getAmount() - 1);
            } else {
                player.getInventory().setItemInMainHand(null);
            }

            activeCooldown.put(uuid, currentTime);
        }
    }

    private void performDimensionalShift(Player player) {
        // Teleport up to 20 blocks in looking direction
        Vector direction = player.getEyeLocation().getDirection().normalize().multiply(20);
        player.teleport(player.getLocation().add(direction));

        // Effects
        player.addPotionEffect(new PotionEffect(PotionEffectType.INVISIBILITY, 40, 0)); // 2 seconds
        player.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, 100, 2)); // 5 seconds Speed III
        player.setFallDistance(0); // Remove fall damage initially

        // Visuals and sounds
        player.getWorld().spawnParticle(Particle.PORTAL, player.getLocation(), 100, 1, 1, 1, 0.1);
        player.getWorld().spawnParticle(Particle.DRAGON_BREATH, player.getLocation(), 50, 1, 1, 1, 0.05);
        player.getWorld().playSound(player.getLocation(), Sound.ENTITY_ENDERMAN_TELEPORT, 1.0f, 1.0f);

        // Fake portal explosion
        new BukkitRunnable() {
            @Override
            public void run() {
                player.getWorld().spawnParticle(Particle.EXPLOSION, player.getLocation(), 10);
            }
        }.runTaskLater(this, 5L);

        // No fall damage for 5 seconds
        new BukkitRunnable() {
            @Override
            public void run() {
                player.setFallDistance(0);
            }
        }.runTaskTimer(this, 0L, 10L); // Check every 0.5s for 5s
    }

    @EventHandler
    public void onEntityDamage(EntityDamageByEntityEvent event) {
        if (!(event.getDamager() instanceof Player) || !(event.getEntity() instanceof Player)) return;

        Player attacker = (Player) event.getDamager();
        Player target = (Player) event.getEntity();

        ItemStack item = attacker.getInventory().getItemInMainHand();
        if (item.getType() != Material.POTION) return;

        ItemMeta meta = item.getItemMeta();
        if (meta == null || !meta.getDisplayName().equals(ChatColor.LIGHT_PURPLE + "§k🌀§r Teleport Potion")) return;

        // Passive: Blink Strike every 10 hits
        UUID uuid = attacker.getUniqueId();
        int hits = hitCounter.getOrDefault(uuid, 0) + 1;
        hitCounter.put(uuid, hits);

        if (hits % 10 == 0) {
            performBlinkStrike(attacker, target);
        }
    }

    private void performBlinkStrike(Player attacker, Player target) {
        // Teleport behind target
        Vector direction = target.getLocation().getDirection().normalize().multiply(-1.5); // Behind
        attacker.teleport(target.getLocation().add(direction).setDirection(attacker.getLocation().getDirection()));

        // Effects
        attacker.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, 40, 1)); // 2s Speed II
        target.addPotionEffect(new PotionEffect(PotionEffectType.WEAKNESS, 60, 0)); // 3s Weakness I

        // Visuals
        attacker.getWorld().spawnParticle(Particle.REVERSE_PORTAL, target.getLocation(), 30);
        attacker.getWorld().spawnParticle(Particle.DRAGON_BREATH, target.getLocation(), 20);
        attacker.getWorld().playSound(target.getLocation(), Sound.ENTITY_ENDERMAN_TELEPORT, 1.0f, 1.0f);

        // Reset counter periodically or leave it (cumulative during potion use)
    }
}