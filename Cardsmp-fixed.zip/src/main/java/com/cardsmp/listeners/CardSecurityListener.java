package com.cardsmp.listeners;

import com.cardsmp.CardsmpPlugin;
import com.cardsmp.cards.CardType;
import com.cardsmp.managers.ActiveCardManager;
import com.cryptomorin.xseries.XAttribute;
import com.cryptomorin.xseries.XPotion;
import com.cryptomorin.xseries.XSound;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.entity.*;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.inventory.InventoryOpenEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.projectiles.ProjectileSource;

import java.util.UUID;

public class CardSecurityListener implements Listener {

    private final CardsmpPlugin plugin;
    private final ActiveCardManager manager;

    public CardSecurityListener(CardsmpPlugin plugin) {
        this.plugin = plugin;
        this.manager = plugin.getActiveCardManager();
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onEntityDamageByEntity(EntityDamageByEntityEvent event) {
        Entity damager = event.getDamager();
        Entity victim = event.getEntity();

        // Unwrap projectile to real attacker
        Entity realAttacker = damager;
        if (damager instanceof Projectile proj) {
            ProjectileSource shooter = proj.getShooter();
            if (shooter instanceof Entity shooterEntity) {
                realAttacker = shooterEntity;
            }
        }

        // COMBAT TRIGGER: player hits player
        if (realAttacker instanceof Player attacker && victim instanceof Player victimPlayer) {
            manager.triggerCombat(attacker.getUniqueId());
            manager.triggerCombat(victimPlayer.getUniqueId());
        }

        // FROZEN PLAYER ATTACK BLOCKED
        if (realAttacker instanceof Player attacker && manager.isFrozen(attacker.getUniqueId())) {
            event.setCancelled(true);
            return;
        }

        // TRACKED MOB DAMAGE
        UUID damagerUUID = damager.getUniqueId();
        if (!manager.isTrackedEntity(damagerUUID)) return;

        UUID ownerUUID = manager.getEntityOwner(damagerUUID);
        if (ownerUUID == null) return;

        // ABSOLUTE RULE: owner is fully immune to their own card effects
        if (victim.getUniqueId().equals(ownerUUID)) {
            event.setCancelled(true);
            return;
        }

        // Passive mode: no damage
        if (!manager.isCombatTriggered(ownerUUID)) {
            event.setCancelled(true);
            return;
        }

        if (!(victim instanceof Player victimPlayer)) return;

        CardType cardType = manager.getActiveCard(ownerUUID);
        if (cardType == null) return;

        // BEE: special sting effects
        if (cardType == CardType.BEE && damager.getType() == EntityType.BEE) {
            event.setCancelled(true);
            handleBeeSting(ownerUUID, victimPlayer);
        }

        // PHANTOM: teleport + levitation
        if (cardType == CardType.PHANTOM && damager.getType() == EntityType.PHANTOM) {
            event.setCancelled(true);
            handlePhantomHit(victimPlayer);
        }
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onEntityDamage(EntityDamageEvent event) {
        // Dragon breath owner immunity
        if (event.getCause() == EntityDamageEvent.DamageCause.DRAGON_BREATH) {
            if (event.getEntity() instanceof Player player) {
                if (manager.getActiveCard(player.getUniqueId()) == CardType.INFINITY
                        && manager.hasActiveCard(player.getUniqueId())) {
                    event.setCancelled(true);
                }
            }
        }
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onPlayerMove(PlayerMoveEvent event) {
        Player player = event.getPlayer();
        if (!manager.isFrozen(player.getUniqueId())) return;

        Location from = event.getFrom();
        Location to = event.getTo();
        if (to == null) return;

        if (from.getX() != to.getX() || from.getY() != to.getY() || from.getZ() != to.getZ()) {
            Location fixed = from.clone();
            fixed.setYaw(to.getYaw());
            fixed.setPitch(to.getPitch());
            event.setTo(fixed);
        }
    }

    @EventHandler
    public void onInventoryOpen(InventoryOpenEvent event) {
        if (manager.isFrozen(event.getPlayer().getUniqueId())) {
            event.setCancelled(true);
        }
    }

    private void handleBeeSting(UUID ownerUUID, Player victim) {
        // Custom 6-heart (12 HP) damage
        victim.damage(12.0);

        // -1 max heart victim (min 1 heart = 2 HP)
        XAttribute.of("GENERIC_MAX_HEALTH").ifPresent(attr -> {
            AttributeInstance ai = victim.getAttribute(attr.get());
            if (ai != null) {
                double newMax = Math.max(2.0, ai.getBaseValue() - 2.0);
                ai.setBaseValue(newMax);
                if (victim.getHealth() > newMax) victim.setHealth(newMax);
            }
        });

        // +1 max heart owner
        org.bukkit.Bukkit.getScheduler().runTask(plugin, () -> {
            Player owner = org.bukkit.Bukkit.getPlayer(ownerUUID);
            if (owner != null && owner.isOnline()) {
                XAttribute.of("GENERIC_MAX_HEALTH").ifPresent(attr -> {
                    AttributeInstance ai = owner.getAttribute(attr.get());
                    if (ai != null) ai.setBaseValue(ai.getBaseValue() + 2.0);
                });
            }
        });

        // FX
        Location loc = victim.getLocation().add(0, 1, 0);
        loc.getWorld().spawnParticle(Particle.DRIPPING_HONEY, loc, 20, 0.5, 0.5, 0.5, 0);
        loc.getWorld().spawnParticle(Particle.CRIT, loc, 15, 0.5, 0.5, 0.5, 0.1);
        XSound.matchXSound("ENTITY_BEE_STING").ifPresent(s ->
            victim.getWorld().playSound(victim.getLocation(), s.get(), 1f, 1f));
        XSound.matchXSound("ENTITY_BEE_HURT").ifPresent(s ->
            victim.getWorld().playSound(victim.getLocation(), s.get(), 1f, 1f));
    }

    private void handlePhantomHit(Player victim) {
        // Teleport high
        victim.teleport(victim.getLocation().clone().add(0, 20, 0));

        // Air curse: Levitation for 15s (300 ticks)
        XPotion.matchXPotion("LEVITATION")
            .map(xp -> xp.buildPotionEffect(300, 0))
            .ifPresent(victim::addPotionEffect);

        // FX
        Location loc = victim.getLocation().add(0, 1, 0);
        loc.getWorld().spawnParticle(Particle.CLOUD, loc, 25, 0.5, 0.5, 0.5, 0.03);
        loc.getWorld().spawnParticle(Particle.PORTAL, loc, 20, 0.5, 0.5, 0.5, 0.1);
        XSound.matchXSound("ENTITY_PHANTOM_HURT").ifPresent(s ->
            victim.getWorld().playSound(victim.getLocation(), s.get(), 1f, 1f));
        XSound.matchXSound("ENTITY_PHANTOM_AMBIENT").ifPresent(s ->
            victim.getWorld().playSound(victim.getLocation(), s.get(), 1f, 0.8f));
    }
}