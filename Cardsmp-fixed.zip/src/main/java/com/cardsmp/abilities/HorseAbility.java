package com.cardsmp.abilities;

import com.cardsmp.CardsmpPlugin;
import com.cardsmp.cards.CardType;
import com.cardsmp.managers.ActiveCardManager;
import com.cryptomorin.xseries.XAttribute;
import com.cryptomorin.xseries.XSound;
import org.bukkit.Color;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Horse;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;

import java.util.UUID;

public class HorseAbility {

    // 20s duration = 200 iterations at 2-tick interval
    private static final int DURATION_ITERATIONS = 200;

    public static void activate(Player owner, CardsmpPlugin plugin) {
        UUID ownerUUID = owner.getUniqueId();
        ActiveCardManager manager = plugin.getActiveCardManager();

        manager.setActiveCard(ownerUUID, CardType.HORSE);

        // Spawn horse
        Location spawnLoc = owner.getLocation();
        Horse horse = (Horse) owner.getWorld().spawnEntity(spawnLoc, EntityType.HORSE);
        horse.setTamed(true);
        horse.setOwner(owner);

        // Saddle the horse
        horse.getInventory().setSaddle(new ItemStack(org.bukkit.Material.SADDLE));

        // Set high speed
        XAttribute.of("GENERIC_MOVEMENT_SPEED").ifPresent(attr -> {
            AttributeInstance ai = horse.getAttribute(attr.get());
            if (ai != null) ai.setBaseValue(0.75);
        });

        horse.addPassenger(owner);
        manager.addEntity(ownerUUID, horse);

        XSound.matchXSound("ENTITY_HORSE_GALLOP").ifPresent(s ->
            owner.getWorld().playSound(owner.getLocation(), s.get(), 2f, 1f));

        int[] ticks = {0};
        Location[] prevLoc = {spawnLoc.clone()};

        BukkitTask task = new BukkitRunnable() {
            @Override
            public void run() {
                if (horse.isDead() || !owner.isOnline() || !manager.hasActiveCard(ownerUUID)) {
                    cancel();
                    return;
                }

                ticks[0]++;
                Location horseLoc = horse.getLocation();

                // Electric spark trail every run
                horse.getWorld().spawnParticle(Particle.ELECTRIC_SPARK, horseLoc, 6, 0.3, 0.3, 0.3, 0.1);

                // Blue dust speed trail
                horse.getWorld().spawnParticle(Particle.DUST,
                    horseLoc.clone().add(0, 0.5, 0), 4, 0.2, 0.2, 0.2, 0,
                    new Particle.DustOptions(Color.fromRGB(100, 150, 255), 1.2f));

                // Lightning effect at previous location every 15 runs
                if (ticks[0] % 15 == 0 && prevLoc[0].distanceSquared(horseLoc) > 1) {
                    // Lightning effect only (no damage)
                    prevLoc[0].getWorld().strikeLightningEffect(prevLoc[0]);
                    XSound.matchXSound("ENTITY_LIGHTNING_BOLT_THUNDER").ifPresent(s ->
                        horseLoc.getWorld().playSound(horseLoc, s.get(), 1.5f, 1.2f));
                }

                prevLoc[0] = horseLoc.clone();

                if (ticks[0] >= DURATION_ITERATIONS) {
                    manager.cleanupPlayer(ownerUUID);
                    cancel();
                }
            }
        }.runTaskTimer(plugin, 0L, 2L);

        manager.addTask(ownerUUID, task);
    }
}