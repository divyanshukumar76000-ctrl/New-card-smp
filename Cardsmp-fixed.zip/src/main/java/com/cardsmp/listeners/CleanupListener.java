package com.cardsmp.listeners;

import com.cardsmp.CardsmpPlugin;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerChangedWorldEvent;
import org.bukkit.event.player.PlayerQuitEvent;

import java.util.UUID;

public class CleanupListener implements Listener {

    private final CardsmpPlugin plugin;

    public CleanupListener(CardsmpPlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onPlayerQuit(PlayerQuitEvent event) {
        cleanup(event.getPlayer());
    }

    @EventHandler
    public void onPlayerDeath(PlayerDeathEvent event) {
        cleanup(event.getEntity());
    }

    @EventHandler
    public void onWorldChange(PlayerChangedWorldEvent event) {
        cleanup(event.getPlayer());
    }

    private void cleanup(Player player) {
        UUID uuid = player.getUniqueId();

        // Clean up active card effects
        if (plugin.getActiveCardManager().hasActiveCard(uuid)) {
            plugin.getActiveCardManager().cleanupPlayer(uuid);
        }

        // If this player was frozen by Fox, restore them
        if (plugin.getActiveCardManager().isFrozen(uuid)) {
            plugin.getActiveCardManager().unfreezePlayer(uuid);
        }
    }
}