package com.elementallegends.managers;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Tracks per-player, per-ability cooldowns and prevents spam-clicking from
 * re-triggering an ability while it's still active or on cooldown.
 */
public class CooldownManager {

    private final Plugin plugin;
    private final Map<UUID, Map<String, Long>> cooldowns = new ConcurrentHashMap<>();
    // Prevents a single held-click from firing an ability more than once.
    private final Map<UUID, Long> lastTrigger = new ConcurrentHashMap<>();

    public CooldownManager(Plugin plugin) {
        this.plugin = plugin;
    }

    public boolean isOnCooldown(Player player, String abilityKey) {
        Map<String, Long> playerCooldowns = cooldowns.get(player.getUniqueId());
        if (playerCooldowns == null) return false;
        Long expiry = playerCooldowns.get(abilityKey);
        return expiry != null && expiry > System.currentTimeMillis();
    }

    public long secondsRemaining(Player player, String abilityKey) {
        Map<String, Long> playerCooldowns = cooldowns.get(player.getUniqueId());
        if (playerCooldowns == null) return 0;
        Long expiry = playerCooldowns.get(abilityKey);
        if (expiry == null) return 0;
        long remainingMs = expiry - System.currentTimeMillis();
        return Math.max(0, remainingMs / 1000);
    }

    public void setCooldown(Player player, String abilityKey, int seconds) {
        cooldowns.computeIfAbsent(player.getUniqueId(), k -> new ConcurrentHashMap<>())
                .put(abilityKey, System.currentTimeMillis() + (seconds * 1000L));

        new BukkitRunnable() {
            @Override
            public void run() {
                if (!player.isOnline()) return;
                if (!isOnCooldown(player, abilityKey)) {
                    player.sendActionBar(Component.text(abilityKey + " is ready!", NamedTextColor.GREEN));
                    player.playSound(player.getLocation(), Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 1f, 1.2f);
                }
            }
        }.runTaskLater(plugin, seconds * 20L);
    }

    /** Simple debounce so a single physical click can't fire twice via duplicate events. */
    public boolean debounce(Player player, long windowMillis) {
        long now = System.currentTimeMillis();
        Long last = lastTrigger.get(player.getUniqueId());
        if (last != null && now - last < windowMillis) {
            return false;
        }
        lastTrigger.put(player.getUniqueId(), now);
        return true;
    }

    public void clearPlayer(UUID uuid) {
        cooldowns.remove(uuid);
        lastTrigger.remove(uuid);
    }
}
