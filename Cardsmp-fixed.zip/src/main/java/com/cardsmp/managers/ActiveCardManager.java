package com.cardsmp.managers;

import com.cardsmp.cards.CardType;
import org.bukkit.Bukkit;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;

import java.util.*;

public class ActiveCardManager {

    private final Map<UUID, CardType> activeCard = new HashMap<>();
    private final Map<UUID, List<BukkitTask>> activeTasks = new HashMap<>();
    private final Map<UUID, List<Entity>> activeEntities = new HashMap<>();
    private final Map<UUID, UUID> entityToOwner = new HashMap<>();
    private final Map<UUID, Boolean> combatTriggered = new HashMap<>();

    // Fox freeze tracking
    private final Map<UUID, List<UUID>> frozenByOwner = new HashMap<>();
    private final Map<UUID, UUID> frozenPlayerOwner = new HashMap<>();
    private final Map<UUID, Float> originalWalkSpeeds = new HashMap<>();

    // ── Active card ──────────────────────────────────────────────────────────

    public void setActiveCard(UUID ownerUUID, CardType type) {
        activeCard.put(ownerUUID, type);
    }

    public boolean hasActiveCard(UUID ownerUUID) {
        return activeCard.containsKey(ownerUUID);
    }

    public CardType getActiveCard(UUID ownerUUID) {
        return activeCard.get(ownerUUID);
    }

    public Set<UUID> getActivePlayers() {
        return new HashSet<>(activeCard.keySet());
    }

    // ── Tasks ────────────────────────────────────────────────────────────────

    public void addTask(UUID ownerUUID, BukkitTask task) {
        activeTasks.computeIfAbsent(ownerUUID, k -> new ArrayList<>()).add(task);
    }

    private void cancelTasks(UUID ownerUUID) {
        List<BukkitTask> tasks = activeTasks.remove(ownerUUID);
        if (tasks != null) {
            for (BukkitTask t : tasks) {
                if (!t.isCancelled()) t.cancel();
            }
        }
    }

    // ── Entities ─────────────────────────────────────────────────────────────

    public void addEntity(UUID ownerUUID, Entity entity) {
        activeEntities.computeIfAbsent(ownerUUID, k -> new ArrayList<>()).add(entity);
        entityToOwner.put(entity.getUniqueId(), ownerUUID);
    }

    public List<Entity> getEntities(UUID ownerUUID) {
        return activeEntities.getOrDefault(ownerUUID, Collections.emptyList());
    }

    public boolean isTrackedEntity(UUID entityUUID) {
        return entityToOwner.containsKey(entityUUID);
    }

    public UUID getEntityOwner(UUID entityUUID) {
        return entityToOwner.get(entityUUID);
    }

    public void removeEntityFromTracking(UUID ownerUUID, Entity entity) {
        List<Entity> list = activeEntities.get(ownerUUID);
        if (list != null) list.remove(entity);
        entityToOwner.remove(entity.getUniqueId());
        if (!entity.isDead()) {
            entity.getPassengers().forEach(Entity::leaveVehicle);
            entity.remove();
        }
    }

    // ── Combat ───────────────────────────────────────────────────────────────

    public boolean isCombatTriggered(UUID ownerUUID) {
        return combatTriggered.getOrDefault(ownerUUID, false);
    }

    public void setCombatTriggered(UUID ownerUUID, boolean value) {
        combatTriggered.put(ownerUUID, value);
    }

    public void triggerCombat(UUID ownerUUID) {
        if (hasActiveCard(ownerUUID)) {
            combatTriggered.put(ownerUUID, true);
        }
    }

    // ── Freeze ───────────────────────────────────────────────────────────────

    public void freezePlayer(UUID ownerUUID, Player target) {
        UUID targetUUID = target.getUniqueId();
        if (frozenPlayerOwner.containsKey(targetUUID)) return;
        frozenByOwner.computeIfAbsent(ownerUUID, k -> new ArrayList<>()).add(targetUUID);
        frozenPlayerOwner.put(targetUUID, ownerUUID);
        originalWalkSpeeds.put(targetUUID, target.getWalkSpeed());
        target.setWalkSpeed(0.0f);
    }

    public void unfreezePlayer(UUID frozenUUID) {
        Float speed = originalWalkSpeeds.remove(frozenUUID);
        frozenPlayerOwner.remove(frozenUUID);

        // Remove from owner's list
        frozenByOwner.values().forEach(list -> list.remove(frozenUUID));

        Player p = Bukkit.getPlayer(frozenUUID);
        if (p != null && p.isOnline() && speed != null) {
            p.setWalkSpeed(speed);
        }
    }

    public void unfreezeAllByOwner(UUID ownerUUID) {
        List<UUID> frozen = frozenByOwner.remove(ownerUUID);
        if (frozen == null) return;
        for (UUID uid : new ArrayList<>(frozen)) {
            Float speed = originalWalkSpeeds.remove(uid);
            frozenPlayerOwner.remove(uid);
            Player p = Bukkit.getPlayer(uid);
            if (p != null && p.isOnline() && speed != null) {
                p.setWalkSpeed(speed);
            }
        }
    }

    public boolean isFrozen(UUID playerUUID) {
        return frozenPlayerOwner.containsKey(playerUUID);
    }

    // ── Cleanup ───────────────────────────────────────────────────────────────

    public void cleanupPlayer(UUID ownerUUID) {
        cancelTasks(ownerUUID);

        List<Entity> entities = activeEntities.remove(ownerUUID);
        if (entities != null) {
            for (Entity entity : entities) {
                entityToOwner.remove(entity.getUniqueId());
                if (!entity.isDead()) {
                    entity.getPassengers().forEach(Entity::leaveVehicle);
                    entity.remove();
                }
            }
        }

        unfreezeAllByOwner(ownerUUID);

        activeCard.remove(ownerUUID);
        combatTriggered.remove(ownerUUID);
    }

    public void clearAll() {
        for (UUID uid : new HashSet<>(activeCard.keySet())) {
            cleanupPlayer(uid);
        }
        activeCard.clear();
        activeTasks.clear();
        activeEntities.clear();
        entityToOwner.clear();
        combatTriggered.clear();
        frozenByOwner.clear();
        frozenPlayerOwner.clear();
        originalWalkSpeeds.clear();
    }

    // ── Utility ──────────────────────────────────────────────────────────────

    public Player getNearestEnemy(Player owner, org.bukkit.Location from, double range) {
        Player nearest = null;
        double nearestDist = range * range;
        for (Player p : owner.getWorld().getPlayers()) {
            if (p.getUniqueId().equals(owner.getUniqueId())) continue;
            if (p.isDead() || !p.isOnline()) continue;
            double dist = p.getLocation().distanceSquared(from);
            if (dist < nearestDist) {
                nearestDist = dist;
                nearest = p;
            }
        }
        return nearest;
    }
}