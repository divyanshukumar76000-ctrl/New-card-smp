package com.cardsmp.cards;

import org.bukkit.NamespacedKey;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.Plugin;

import java.util.Arrays;
import java.util.UUID;

public class CardItem {

    public static final String PDC_CARD_TYPE = "card_type";
    public static final String PDC_CARD_UID = "card_unique_id";

    private static final String[][] LORE = {
        {"&7Summons a Ravager", "&7Passive until combat"},
        {"&7Explosive sky chickens", "&7Instant ability"},
        {"&7Rideable lightning horse", "&7Movement trail"},
        {"&7Freezes nearby enemies", "&720 second freeze"},
        {"&7Bee swarm steals hearts", "&7Active until removed"},
        {"&7Phantoms orbit and suspend", "&7Aerial curse"},
        {"&7Summons an Ender Dragon", "&7Passive until combat"}
    };

    private static final String[] COLORS = {
        "&c", "&f", "&6", "&e", "&e", "&8", "&5"
    };

    public static ItemStack createCard(Plugin plugin, CardType type) {
        ItemStack item = type.getMaterial().parseItem();
        if (item == null) return null;

        ItemMeta meta = item.getItemMeta();
        if (meta == null) return item;

        int ordinal = type.ordinal();
        String color = COLORS[ordinal];
        meta.setDisplayName(color + "&l" + type.getDisplayName() + " Card");

        String[] loreLines = LORE[ordinal];
        meta.setLore(Arrays.asList(loreLines));

        meta.setUnbreakable(true);
        meta.setCustomModelData(type.getCustomModelData());

        NamespacedKey typeKey = new NamespacedKey(plugin, PDC_CARD_TYPE);
        NamespacedKey uidKey = new NamespacedKey(plugin, PDC_CARD_UID);
        meta.getPersistentDataContainer().set(typeKey, PersistentDataType.STRING, type.name());
        meta.getPersistentDataContainer().set(uidKey, PersistentDataType.STRING, UUID.randomUUID().toString());

        item.setItemMeta(meta);
        return item;
    }

    public static CardType getCardType(Plugin plugin, ItemStack item) {
        if (item == null || !item.hasItemMeta()) return null;
        ItemMeta meta = item.getItemMeta();
        if (meta == null) return null;
        NamespacedKey key = new NamespacedKey(plugin, PDC_CARD_TYPE);
        String typeName = meta.getPersistentDataContainer().get(key, PersistentDataType.STRING);
        if (typeName == null) return null;
        try {
            return CardType.valueOf(typeName);
        } catch (IllegalArgumentException e) {
            return null;
        }
    }

    public static boolean isCard(Plugin plugin, ItemStack item) {
        if (item == null || !item.hasItemMeta()) return false;
        ItemMeta meta = item.getItemMeta();
        if (meta == null) return false;
        NamespacedKey typeKey = new NamespacedKey(plugin, PDC_CARD_TYPE);
        NamespacedKey uidKey = new NamespacedKey(plugin, PDC_CARD_UID);
        return meta.getPersistentDataContainer().has(typeKey, PersistentDataType.STRING)
            && meta.getPersistentDataContainer().has(uidKey, PersistentDataType.STRING);
    }
}