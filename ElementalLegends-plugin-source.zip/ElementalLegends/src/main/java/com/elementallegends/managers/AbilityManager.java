package com.elementallegends.managers;

import org.bukkit.*;
import org.bukkit.attribute.Attribute;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.*;
import org.bukkit.plugin.Plugin;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

import java.util.List;
import java.util.UUID;

/**
 * Implements the actual gameplay effects for every ability. Numbers are
 * pulled from config.yml so server owners can retune balance without
 * touching code.
 */
public class AbilityManager {

    private final Plugin plugin;
    private final FileConfiguration cfg;

    public AbilityManager(Plugin plugin) {
        this.plugin = plugin;
        this.cfg = plugin.getConfig();
    }

    // ---------------------------------------------------------------- FIRE

    public void infernoStrike(Player user) {
        Entity target = getTargetEntity(user, 6);
        playSound(user.getLocation(), Sound.ENTITY_ENDER_DRAGON_GROWL, 1f, 1f);
        spawnParticles(user.getLocation().add(0, 1, 0), Particle.FLAME, 60, 0.5, 1, 0.5);
        spawnParticles(user.getLocation(), Particle.LAVA, 30, 0.5, 0.5, 0.5);

        if (target instanceof LivingEntity living && target != user) {
            living.setHealth(0);
            living.getWorld().playSound(living.getLocation(), Sound.ENTITY_GENERIC_EXPLODE, 1f, 1f);
            living.getWorld().spawnParticle(Particle.EXPLOSION, living.getLocation(), 3);
        }
    }

    public void infernoApocalypse(Player user) {
        int radius = cfg.getInt("items.fire-sword.ability2.radius", 20);
        double diamondArmorDamageHearts = cfg.getDouble("items.fire-sword.ability2.diamond-armor-damage-hearts", 8);
        int fireRemain = cfg.getInt("items.fire-sword.ability2.fire-remain-seconds", 20);

        Location center = user.getLocation();
        spawnParticles(center, Particle.FLAME, 200, radius / 2.0, 1, radius / 2.0);
        spawnParticles(center, Particle.SMOKE, 100, radius / 2.0, 1, radius / 2.0);
        playSound(center, Sound.ENTITY_GENERIC_EXPLODE, 2f, 0.8f);
        playSound(center, Sound.ITEM_FIRECHARGE_USE, 2f, 0.6f);

        for (Entity entity : center.getWorld().getNearbyEntities(center, radius, radius, radius)) {
            if (entity == user || !(entity instanceof LivingEntity living)) continue;

            if (entity instanceof Player targetPlayer) {
                if (hasFullDiamondArmor(targetPlayer)) {
                    living.damage(diamondArmorDamageHearts * 2.0, user); // hearts -> half-hearts damage
                } else {
                    living.setHealth(0);
                }
            } else {
                living.setHealth(0);
            }
            living.setFireTicks(fireRemain * 20);
        }

        // Fire pillar ring effect
        for (int i = 0; i < 16; i++) {
            double angle = 2 * Math.PI * i / 16;
            Location pillar = center.clone().add(Math.cos(angle) * radius * 0.6, 0, Math.sin(angle) * radius * 0.6);
            spawnParticles(pillar, Particle.FLAME, 20, 0.2, 2, 0.2);
        }
    }

    // --------------------------------------------------------------- WATER

    public void oceanCurse(Player user) {
        int radius = cfg.getInt("items.water-sword.ability1.radius", 30);
        int duration = cfg.getInt("items.water-sword.ability1.duration-seconds", 10);

        Location center = user.getLocation();
        spawnParticles(center, Particle.BUBBLE_POP, 150, radius / 2.0, 1, radius / 2.0);
        spawnParticles(center, Particle.SPLASH, 100, radius / 2.0, 1, radius / 2.0);
        playSound(center, Sound.ENTITY_DOLPHIN_SPLASH, 2f, 0.7f);

        for (Entity entity : center.getWorld().getNearbyEntities(center, radius, radius, radius)) {
            if (!(entity instanceof Player targetPlayer) || targetPlayer == user) continue;
            targetPlayer.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, duration * 20, 4));
            targetPlayer.addPotionEffect(new PotionEffect(PotionEffectType.WEAKNESS, duration * 20, 0));
            targetPlayer.addPotionEffect(new PotionEffect(PotionEffectType.MINING_FATIGUE, duration * 20, 0));
        }
    }

    public void tntWaterTrap(Player user) {
        int radius = cfg.getInt("items.water-sword.ability2.radius", 30);
        int tntCount = cfg.getInt("items.water-sword.ability2.tnt-count", 10);

        Location center = user.getLocation();
        spawnParticles(center, Particle.SPLASH, 100, radius / 2.0, 1, radius / 2.0);
        playSound(center, Sound.ENTITY_GENERIC_EXPLODE, 1.5f, 1.2f);

        for (Entity entity : center.getWorld().getNearbyEntities(center, radius, radius, radius)) {
            if (!(entity instanceof Player targetPlayer) || targetPlayer == user) continue;
            for (int i = 0; i < tntCount; i++) {
                Location tntLoc = targetPlayer.getLocation().clone().add(
                        (Math.random() - 0.5) * 3, 1 + Math.random(), (Math.random() - 0.5) * 3);
                TNTPrimed tnt = (TNTPrimed) targetPlayer.getWorld().spawnEntity(tntLoc, EntityType.TNT);
                tnt.setFuseTicks(30);
                tnt.setSource(user);
            }
        }
    }

    // ------------------------------------------------------------- THUNDER

    public void thunderStorm(Player user) {
        int radius = cfg.getInt("items.thunder-sword.ability1.radius", 50);
        int duration = cfg.getInt("items.thunder-sword.ability1.duration-seconds", 20);
        double enemyChance = cfg.getDouble("items.thunder-sword.ability1.strike-enemy-chance", 0.8);
        World world = user.getWorld();
        Location center = user.getLocation();

        UUID userId = user.getUniqueId();

        new BukkitRunnable() {
            int ticks = 0;

            @Override
            public void run() {
                if (ticks >= duration * 20 || !user.isOnline()) {
                    this.cancel();
                    return;
                }
                if (ticks % 20 == 0) {
                    List<Player> nearby = world.getPlayers().stream()
                            .filter(p -> !p.getUniqueId().equals(userId))
                            .filter(p -> p.getLocation().distance(center) <= radius)
                            .toList();

                    Location strikeLoc;
                    if (!nearby.isEmpty() && Math.random() < enemyChance) {
                        Player target = nearby.get((int) (Math.random() * nearby.size()));
                        strikeLoc = target.getLocation();
                        world.strikeLightning(strikeLoc);
                        TNTPrimed tnt = (TNTPrimed) world.spawnEntity(strikeLoc, EntityType.TNT);
                        tnt.setFuseTicks(20);
                        tnt.setSource(user);
                    } else {
                        double x = center.getX() + (Math.random() - 0.5) * radius * 2;
                        double z = center.getZ() + (Math.random() - 0.5) * radius * 2;
                        strikeLoc = new Location(world, x, center.getY(), z);
                        world.strikeLightningEffect(strikeLoc);
                    }
                }
                ticks += 20;
            }
        }.runTaskTimer(plugin, 0L, 20L);
    }

    public void divineThunder(Player user) {
        Entity target = getTargetEntity(user, 8);
        playSound(user.getLocation(), Sound.ENTITY_LIGHTNING_BOLT_THUNDER, 2f, 1f);

        if (target instanceof LivingEntity living && target != user) {
            living.getWorld().strikeLightning(living.getLocation());
            living.setHealth(0);
        } else {
            // No target: strike where the user is looking, for the visual.
            Location strike = user.getEyeLocation().add(user.getEyeLocation().getDirection().multiply(6));
            user.getWorld().strikeLightningEffect(strike);
        }
    }

    // --------------------------------------------------------------- MACE

    public void voidSmash(Player user) {
        int radius = cfg.getInt("items.void-mace.ability1.radius", 15);
        double damage = cfg.getDouble("items.void-mace.ability1.damage", 20.0);

        Location center = user.getLocation();
        spawnParticles(center, Particle.PORTAL, 150, radius / 2.0, 0.5, radius / 2.0);
        spawnParticles(center, Particle.EXPLOSION, 5, 1, 0.2, 1);
        playSound(center, Sound.ENTITY_WARDEN_SONIC_BOOM, 1.5f, 0.8f);

        for (Entity entity : center.getWorld().getNearbyEntities(center, radius, radius, radius)) {
            if (entity == user || !(entity instanceof LivingEntity living)) continue;
            living.damage(damage, user);
            living.setVelocity(living.getVelocity().add(new Vector(0, 1.4, 0)));
        }
    }

    public void voidMeteor(Player user) {
        int radius = cfg.getInt("items.void-mace.ability2.radius", 25);
        double damage = cfg.getDouble("items.void-mace.ability2.damage", 30.0);

        Location target = getGroundTarget(user, 20);
        Location skyStart = target.clone().add(0, 25, 0);

        spawnParticles(skyStart, Particle.DRAGON_BREATH, 40, 0.5, 0.5, 0.5);
        playSound(target, Sound.ENTITY_ENDER_DRAGON_HURT, 2f, 0.7f);

        new BukkitRunnable() {
            int step = 0;

            @Override
            public void run() {
                if (step >= 15) {
                    // Impact
                    spawnParticles(target, Particle.EXPLOSION_EMITTER, 3, 0.5, 0.5, 0.5);
                    spawnParticles(target, Particle.PORTAL, 200, radius / 2.0, 1, radius / 2.0);
                    playSound(target, Sound.ENTITY_GENERIC_EXPLODE, 2f, 0.6f);
                    for (Entity entity : target.getWorld().getNearbyEntities(target, radius, radius, radius)) {
                        if (entity == user || !(entity instanceof LivingEntity living)) continue;
                        living.damage(damage, user);
                    }
                    this.cancel();
                    return;
                }
                Location current = skyStart.clone().add(0, -step * 1.6, 0);
                spawnParticles(current, Particle.FLAME, 5, 0.2, 0.2, 0.2);
                step++;
            }
        }.runTaskTimer(plugin, 0L, 2L);
    }

    // -------------------------------------------------------------- ARMOR

    public void voidArrowApocalypse(Player user) {
        int radius = cfg.getInt("items.void-armor.ability1.radius", 30);
        int arrowCount = cfg.getInt("items.void-armor.ability1.arrow-count", 60);
        double damagePerArrow = cfg.getDouble("items.void-armor.ability1.damage-per-arrow", 3.0);

        Location center = user.getLocation().add(0, 1, 0);
        playSound(center, Sound.ENTITY_ARROW_SHOOT, 2f, 0.7f);
        spawnParticles(center, Particle.PORTAL, 100, 1, 1, 1);

        for (int i = 0; i < arrowCount; i++) {
            double angle = 2 * Math.PI * i / arrowCount;
            Vector direction = new Vector(Math.cos(angle), 0.1, Math.sin(angle));
            Arrow arrow = user.getWorld().spawnArrow(center, direction, 2.2f, 0f);
            arrow.setShooter(user);
            arrow.setDamage(damagePerArrow);
            arrow.setPierceLevel(1);
            arrow.setColor(Color.PURPLE);
        }
    }

    public void voidDimensionPrison(Player user) {
        int duration = cfg.getInt("items.void-armor.ability2.duration-seconds", 10);
        Entity target = getTargetEntity(user, 6);

        if (!(target instanceof Player targetPlayer) || targetPlayer == user) {
            user.sendMessage(Component_error());
            return;
        }

        Location originalLocation = targetPlayer.getLocation().clone();
        World voidWorld = user.getWorld(); // Uses same world at high Y as a stand-in "void dimension"
        Location prisonLoc = new Location(voidWorld, targetPlayer.getLocation().getX(), 320, targetPlayer.getLocation().getZ());

        playSound(targetPlayer.getLocation(), Sound.ENTITY_ENDERMAN_TELEPORT, 2f, 0.5f);
        spawnParticles(targetPlayer.getLocation(), Particle.PORTAL, 150, 1, 1, 1);
        targetPlayer.teleport(prisonLoc);
        targetPlayer.setGameMode(GameMode.ADVENTURE);
        targetPlayer.setAllowFlight(true);
        targetPlayer.setFlying(true);

        new BukkitRunnable() {
            @Override
            public void run() {
                if (!targetPlayer.isOnline()) return;
                spawnParticles(targetPlayer.getLocation(), Particle.PORTAL, 150, 1, 1, 1);
                targetPlayer.setAllowFlight(false);
                targetPlayer.setFlying(false);
                targetPlayer.setGameMode(GameMode.SURVIVAL);
                targetPlayer.teleport(originalLocation);
                playSound(originalLocation, Sound.ENTITY_ENDERMAN_TELEPORT, 2f, 0.8f);
            }
        }.runTaskLater(plugin, duration * 20L);
    }

    // ------------------------------------------------------------- HELPERS

    private net.kyori.adventure.text.Component Component_error() {
        return net.kyori.adventure.text.Component.text("No valid target found.")
                .color(net.kyori.adventure.text.format.NamedTextColor.RED);
    }

    private Entity getTargetEntity(Player user, double range) {
        List<Entity> nearby = user.getNearbyEntities(range, range, range);
        Entity closest = null;
        double closestDistSq = Double.MAX_VALUE;
        Vector eyeDir = user.getEyeLocation().getDirection().normalize();

        for (Entity entity : nearby) {
            if (!(entity instanceof LivingEntity) || entity == user) continue;
            Vector toEntity = entity.getLocation().toVector().subtract(user.getEyeLocation().toVector());
            double distSq = toEntity.lengthSquared();
            if (distSq > range * range) continue;
            toEntity.normalize();
            if (eyeDir.dot(toEntity) > 0.7) { // roughly in front of the player
                if (distSq < closestDistSq) {
                    closestDistSq = distSq;
                    closest = entity;
                }
            }
        }
        return closest;
    }

    private Location getGroundTarget(Player user, double maxDistance) {
        var result = user.rayTraceBlocks(maxDistance);
        if (result != null && result.getHitPosition() != null) {
            return result.getHitPosition().toLocation(user.getWorld());
        }
        return user.getLocation().add(user.getLocation().getDirection().multiply(10));
    }

    private boolean hasFullDiamondArmor(Player player) {
        var inv = player.getInventory();
        return inv.getHelmet() != null && inv.getHelmet().getType() == Material.DIAMOND_HELMET
                && inv.getChestplate() != null && inv.getChestplate().getType() == Material.DIAMOND_CHESTPLATE
                && inv.getLeggings() != null && inv.getLeggings().getType() == Material.DIAMOND_LEGGINGS
                && inv.getBoots() != null && inv.getBoots().getType() == Material.DIAMOND_BOOTS;
    }

    private void spawnParticles(Location loc, Particle particle, int count, double dx, double dy, double dz) {
        if (!cfg.getBoolean("particles.enabled", true)) return;
        loc.getWorld().spawnParticle(particle, loc, count, dx, dy, dz, 0.02);
    }

    private void playSound(Location loc, Sound sound, float volume, float pitch) {
        if (!cfg.getBoolean("sounds.enabled", true)) return;
        loc.getWorld().playSound(loc, sound, volume, pitch);
    }
}
