package com.potionsmp.listeners;

import com.potionsmp.PotionSMP;
import com.potionsmp.abilities.Ability;
import com.potionsmp.managers.SlotManager;
import com.potionsmp.utils.PotionType;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerRespawnEvent;

import java.util.UUID;

/**
 * Re-applies each equipped slot's passive after two events where the
 * player's actual potion effects are gone but {@link SlotManager}'s
 * bookkeeping isn't:
 *
 *  - Respawn: vanilla Minecraft wipes ALL potion effects on death/respawn.
 *    There's no per-plugin opt-out for that, so anything a player had
 *    equipped needs to be handed back afterward.
 *  - Join: SlotManager is in-memory only and nothing ever calls
 *    clearAll(uuid) on quit, so a player who disconnects and reconnects
 *    (without a server/plugin restart) still shows as having Slot 1/2
 *    equipped internally, but a fresh login has no effects at all.
 *
 * This only ever calls onEquip() for the PotionType already recorded in
 * that player's own slots — it never touches any other player, any other
 * effect, or any effect the player may have from an unrelated source (a
 * real brewed potion, a beacon, etc.), since onEquip() implementations only
 * add the specific effect type(s) that ability owns.
 */
public class PassiveReapplyListener implements Listener {

    private final PotionSMP plugin;

    public PassiveReapplyListener(PotionSMP plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onRespawn(PlayerRespawnEvent event) {
        // Respawn's own effect wipe happens as part of the same event cycle;
        // defer one tick so this runs after that wipe rather than racing it.
        reapplyNextTick(event.getPlayer());
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onJoin(PlayerJoinEvent event) {
        reapplyNextTick(event.getPlayer());
    }

    private void reapplyNextTick(Player player) {
        UUID uid = player.getUniqueId();
        SlotManager slots = plugin.getSlotManager();

        PotionType slot1 = slots.getSlot1(uid);
        PotionType slot2 = slots.getSlot2(uid);
        if (slot1 == null && slot2 == null) return;

        plugin.getServer().getScheduler().runTask(plugin, () -> {
            if (!player.isOnline()) return;
            reapply(player, slot1);
            // Don't double-apply if both slots hold the same type — the
            // first call already covers it.
            if (slot2 != null && slot2 != slot1) reapply(player, slot2);
        });
    }

    private void reapply(Player player, PotionType type) {
        if (type == null) return;
        Ability ability = plugin.getAbilityRegistry().get(type);
        if (ability != null) ability.onEquip(plugin, player);
    }
}
