package com.potionsmp.listeners;

import com.potionsmp.PotionSMP;
import com.potionsmp.abilities.Ability;
import com.potionsmp.managers.SlotManager;
import com.potionsmp.utils.PotionType;
import com.potionsmp.utils.PotionUtils;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerItemConsumeEvent;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

/**
 * Equips drunk potions into Slot 1. Strips the vanilla base-effect one tick
 * after consumption (uses isInfinite() to avoid accidentally removing any
 * custom permanent passive the ability's onEquip() just applied).
 */
public class DrinkListener implements Listener {

    private final PotionSMP plugin;

    public DrinkListener(PotionSMP plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onConsume(PlayerItemConsumeEvent event) {
        PotionType type = PotionUtils.getPotionType(event.getItem());
        if (type == null) return;

        Player player = event.getPlayer();

        // Strip vanilla base-effect one tick after drinking (after MC applies it)
        PotionEffectType vanillaEffect = vanillaEffectFor(type);
        if (vanillaEffect != null) {
            plugin.getServer().getScheduler().runTask(plugin, () -> {
                if (!player.isOnline()) return;
                PotionEffect active = player.getPotionEffect(vanillaEffect);
                // Only strip finite-duration (vanilla burst), never infinite (custom passive)
                if (active != null && !active.isInfinite()) {
                    player.removePotionEffect(vanillaEffect);
                }
            });
        }

        SlotManager slots = plugin.getSlotManager();
        PotionType previous = slots.setSlot1(player.getUniqueId(), type);

        if (previous != null && previous != type) {
            Ability oldAbility = plugin.getAbilityRegistry().get(previous);
            if (oldAbility != null) oldAbility.onUnequip(plugin, player);
            player.sendMessage(PotionUtils.msg("slot-replaced")
                    .replace("%slot%", "1")
                    .replace("%old%", previous.getDisplayName()));
        }

        Ability newAbility = plugin.getAbilityRegistry().get(type);
        if (newAbility != null) newAbility.onEquip(plugin, player);

        player.sendMessage(PotionUtils.msg("drank-potion")
                .replace("%potion%", type.getDisplayName())
                .replace("%slot%", "1"));
    }

    private PotionEffectType vanillaEffectFor(PotionType type) {
        return switch (type) {
            case FIRE -> PotionEffectType.FIRE_RESISTANCE;
            case FREEZE -> PotionEffectType.SLOWNESS;
            case REGEN -> PotionEffectType.REGENERATION;
        };
    }
}
