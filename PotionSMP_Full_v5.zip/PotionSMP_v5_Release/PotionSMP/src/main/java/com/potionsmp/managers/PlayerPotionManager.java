package com.potionsmp.managers;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

/**
 * Tracks which potion abilities each player has permanently unlocked by drinking.
 * Fire and Freeze are independent - a player can have BOTH active at the same time,
 * each with its own passive hit-counter and its own cooldown, triggered separately
 * via /lspark (fire) and /rspark (freeze).
 */
public class PlayerPotionManager {

    public static final String FIRE = "fire";
    public static final String FREEZE = "freeze";

    private final Set<UUID> fireUnlocked = new HashSet<>();
    private final Set<UUID> freezeUnlocked = new HashSet<>();

    public void unlockFire(UUID uuid) {
        fireUnlocked.add(uuid);
    }

    public void unlockFreeze(UUID uuid) {
        freezeUnlocked.add(uuid);
    }

    public boolean isFireActive(UUID uuid) {
        return fireUnlocked.contains(uuid);
    }

    public boolean isFreezeActive(UUID uuid) {
        return freezeUnlocked.contains(uuid);
    }

    public boolean hasAny(UUID uuid) {
        return isFireActive(uuid) || isFreezeActive(uuid);
    }

    public void clearFire(UUID uuid) {
        fireUnlocked.remove(uuid);
    }

    public void clearFreeze(UUID uuid) {
        freezeUnlocked.remove(uuid);
    }

    public void clearAll(UUID uuid) {
        fireUnlocked.remove(uuid);
        freezeUnlocked.remove(uuid);
    }
}
