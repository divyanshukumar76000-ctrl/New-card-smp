package com.cardsmp.cards;

import com.cryptomorin.xseries.XMaterial;

public enum CardType {
    WARRIOR("Warrior", XMaterial.RED_DYE, 1),
    CHICKEN("Chicken", XMaterial.WHITE_DYE, 2),
    HORSE("Horse", XMaterial.BROWN_DYE, 3),
    FOX("Fox", XMaterial.ORANGE_DYE, 4),
    BEE("Bee", XMaterial.YELLOW_DYE, 5),
    PHANTOM("Phantom", XMaterial.BLACK_DYE, 6),
    INFINITY("Infinity", XMaterial.PURPLE_DYE, 7);

    private final String displayName;
    private final XMaterial material;
    private final int customModelData;

    CardType(String displayName, XMaterial material, int customModelData) {
        this.displayName = displayName;
        this.material = material;
        this.customModelData = customModelData;
    }

    public String getDisplayName() {
        return displayName;
    }

    public XMaterial getMaterial() {
        return material;
    }

    public int getCustomModelData() {
        return customModelData;
    }
}