package com.cardsmp.listeners;

import com.cardsmp.CardsmpPlugin;
import com.cardsmp.abilities.*;
import com.cardsmp.cards.CardItem;
import com.cardsmp.cards.CardType;
import com.cardsmp.managers.ActiveCardManager;
import com.cardsmp.managers.CooldownManager;
import com.cardsmp.util.ColorUtil;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;

import java.util.UUID;

public class CardUseListener implements Listener {

    private final CardsmpPlugin plugin;
    private final CooldownManager cooldownManager;
    private final ActiveCardManager activeCardManager;

    public CardUseListener(CardsmpPlugin plugin) {
        this.plugin = plugin;
        this.cooldownManager = plugin.getCooldownManager();
        this.activeCardManager = plugin.getActiveCardManager();
    }

    @EventHandler
    public void onPlayerInteract(PlayerInteractEvent event) {
        Action action = event.getAction();
        if (action != Action.RIGHT_CLICK_AIR && action != Action.RIGHT_CLICK_BLOCK) return;
        if (event.getHand() != EquipmentSlot.HAND) return;

        var player = event.getPlayer();
        ItemStack item = player.getInventory().getItemInMainHand();

        // Validate PDC
        if (!CardItem.isCard(plugin, item)) return;
        CardType cardType = CardItem.getCardType(plugin, item);
        if (cardType == null) return;

        event.setCancelled(true);

        UUID uuid = player.getUniqueId();

        // Cooldown check
        if (cooldownManager.isOnCooldown(uuid)) {
            long remaining = cooldownManager.getRemainingSeconds(uuid);
            player.sendActionBar(ColorUtil.colorize("&cCooldown: &f" + remaining + "s"));
            return;
        }

        // Cleanup previous active card
        if (activeCardManager.hasActiveCard(uuid)) {
            activeCardManager.cleanupPlayer(uuid);
        }

        // Set cooldown
        cooldownManager.setCooldown(uuid);

        // Activate ability
        switch (cardType) {
            case WARRIOR -> WarriorAbility.activate(player, plugin);
            case CHICKEN -> ChickenAbility.activate(player, plugin);
            case HORSE   -> HorseAbility.activate(player, plugin);
            case FOX     -> FoxAbility.activate(player, plugin);
            case BEE     -> BeeAbility.activate(player, plugin);
            case PHANTOM -> PhantomAbility.activate(player, plugin);
            case INFINITY -> InfinityAbility.activate(player, plugin);
        }
    }
}