package com.elementallegends.gui;

import com.elementallegends.items.ItemFactory;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Bukkit;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

public final class MenuFactory {

    public static final String SWORD_TITLE_KEY = "el_sword_menu";
    public static final String MACE_TITLE_KEY = "el_mace_menu";
    public static final String AURA_TITLE_KEY = "el_aura_menu";

    private MenuFactory() {}

    public static Inventory swordMenu() {
        Inventory inv = Bukkit.createInventory(null, 27,
                Component.text("⚔ Elemental Swords ⚔", NamedTextColor.GOLD, TextDecoration.BOLD));
        inv.setItem(11, ItemFactory.fireSword());
        inv.setItem(13, ItemFactory.waterSword());
        inv.setItem(15, ItemFactory.thunderSword());
        return inv;
    }

    public static Inventory maceMenu() {
        Inventory inv = Bukkit.createInventory(null, 27,
                Component.text("💥 Legendary Mace GUI", NamedTextColor.DARK_PURPLE, TextDecoration.BOLD));
        inv.setItem(13, ItemFactory.voidMace());
        return inv;
    }

    public static Inventory auraMenu() {
        Inventory inv = Bukkit.createInventory(null, 27,
                Component.text("🛡 Void Armor GUI", NamedTextColor.DARK_PURPLE, TextDecoration.BOLD));
        inv.setItem(10, ItemFactory.voidHelmet());
        inv.setItem(12, ItemFactory.voidChestplate());
        inv.setItem(14, ItemFactory.voidLeggings());
        inv.setItem(16, ItemFactory.voidBoots());
        return inv;
    }

    /** Fresh copies of items are handed out on every click, so claiming is unlimited by design. */
    public static ItemStack copy(ItemStack source) {
        return source.clone();
    }
}
