package com.potionsmp.listeners;

import com.potionsmp.PotionSMP;
import com.potionsmp.utils.PotionUtils;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

/**
 * Handles the Fire Potion's PASSIVE ability only.
 * The ACTIVE ability (Inferno Rage) is triggered via the /lspark command
 * (see PotionCommand), so it can be bound to a key with a client-side
 * bind-command mod.
 */
public class FirePotionListener implements Listener {

    private final PotionSMP plugin;

    public FirePotionListener(PotionSMP plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onHit(EntityDamageByEntityEvent event) {
        if (!(event.getDamager() instanceof Player player)) return;
        if (!(event.getEntity() instanceof LivingEntity target)) return;

        if (!plugin.getPlayerPotionManager().isFireActive(player.getUniqueId())) return;

        int hits = plugin.getHitCounterManager().incrementFire(player.getUniqueId());
        int threshold = plugin.getConfig().getInt("fire-potion.passive-hits", 10);

        if (hits >= threshold) {
            plugin.getHitCounterManager().resetFire(player.getUniqueId());

            Location targetLoc = target.getLocation();
            int igniteRadius = 3;

            target.setFireTicks(100);

            for (Entity e : targetLoc.getWorld().getNearbyEntities(targetLoc, igniteRadius, igniteRadius, igniteRadius)) {
                if (e instanceof LivingEntity le && !e.getUniqueId().equals(player.getUniqueId())) {
                    le.setFireTicks(80);
                }
            }

            targetLoc.getWorld().spawnParticle(Particle.FLAME, targetLoc.add(0, 1, 0), 30, 0.5, 0.5, 0.5, 0.08);
            targetLoc.getWorld().spawnParticle(Particle.LAVA, targetLoc, 5, 0.3, 0.3, 0.3, 0);
            targetLoc.getWorld().playSound(targetLoc, Sound.ENTITY_BLAZE_SHOOT, 1f, 0.8f);
            player.sendMessage(PotionUtils.colorize("&c🔥 Passive fire ignition triggered!"));
        } else {
            target.getWorld().spawnParticle(Particle.FLAME, target.getLocation().add(0, 1, 0), 2, 0.2, 0.2, 0.2, 0.01);
        }
    }

    /**
     * Activates Inferno Rage for the given player. Called from /lspark.
     * Returns true if activated, false if it was blocked (no potion / on cooldown).
     */
    public static ActivationResult activate(PotionSMP plugin, Player player) {
        if (!plugin.getPlayerPotionManager().isFireActive(player.getUniqueId())) {
            return ActivationResult.NO_POTION;
        }

        if (plugin.getCooldownManager().isOnCooldown(player.getUniqueId(), PotionUtils.FIRE)) {
            return ActivationResult.ON_COOLDOWN;
        }

        int radius = plugin.getConfig().getInt("fire-potion.active-fire-radius", 2);
        int duration = plugin.getConfig().getInt("fire-potion.active-duration", 200);
        int cooldown = plugin.getConfig().getInt("fire-potion.active-cooldown", 30);
        int fireResDuration = plugin.getConfig().getInt("fire-potion.fire-resistance-duration", 200);

        plugin.getCooldownManager().setCooldown(player.getUniqueId(), PotionUtils.FIRE, cooldown);
        player.sendMessage(PotionUtils.msg("fire-active"));

        player.addPotionEffect(new PotionEffect(PotionEffectType.FIRE_RESISTANCE, fireResDuration, 0, false, true));

        Location loc = player.getLocation();
        loc.getWorld().spawnParticle(Particle.FLAME, loc.clone().add(0, 1, 0), 80, radius, 1, radius, 0.15);
        loc.getWorld().spawnParticle(Particle.LAVA, loc.clone().add(0, 1, 0), 20, radius, 0.5, radius, 0.1);
        loc.getWorld().playSound(loc, Sound.ENTITY_BLAZE_SHOOT, 1.5f, 0.6f);
        loc.getWorld().playSound(loc, Sound.ENTITY_GHAST_SHOOT, 0.8f, 1.2f);

        plugin.getFireAuraManager().activateInfernoAura(player, duration, radius);

        return ActivationResult.SUCCESS;
    }

    public enum ActivationResult {
        SUCCESS, NO_POTION, ON_COOLDOWN
    }
}
