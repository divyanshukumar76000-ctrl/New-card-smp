package com.potionsmp.abilities;

import com.potionsmp.utils.PotionType;

import java.util.HashMap;
import java.util.Map;

/**
 * Central registry mapping each PotionType to its Ability implementation.
 * To add one of the remaining 6 potions later: implement a new Ability class,
 * then register it here.
 */
public class AbilityRegistry {

    private final Map<PotionType, Ability> abilities = new HashMap<>();

    public AbilityRegistry() {
        register(new FireAbility());
        register(new FreezeAbility());
        register(new RegenAbility());
    }

    private void register(Ability ability) {
        abilities.put(ability.type(), ability);
    }

    public Ability get(PotionType type) {
        return abilities.get(type);
    }
}
