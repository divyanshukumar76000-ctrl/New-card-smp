package com.potionsmp.hud;

import com.potionsmp.PotionSMP;
import com.potionsmp.utils.PotionType;
import net.kyori.adventure.key.Key;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.Style;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;

import java.util.EnumMap;
import java.util.Map;

public class HudManager {

    private static final Key ICON_FONT = Key.key("minecraft", "potionsmp");

    // Slot background char (empty.png mapped to \uE010 in potionsmp font)
    private static final String SLOT_BG = "\uE010";

    // Negative-advance space from Minecraft's built-in negative-space font.
    // \uF808 shifts the cursor back ~8px so the icon overlaps the slot background.
    private static final String NEG_SPACE = "\uF808";

    private record IconInfo(String character, NamedTextColor color) {}

    private static final Map<PotionType, IconInfo> ICONS = new EnumMap<>(PotionType.class);
    static {
        ICONS.put(PotionType.FIRE,   new IconInfo("\uE000", NamedTextColor.RED));
        ICONS.put(PotionType.FREEZE, new IconInfo("\uE001", NamedTextColor.AQUA));
        ICONS.put(PotionType.REGEN,  new IconInfo("\uE002", NamedTextColor.GREEN));
    }

    private final PotionSMP plugin;
    private BukkitTask task;

    public HudManager(PotionSMP plugin) {
        this.plugin = plugin;
    }

    public void start() {
        task = Bukkit.getScheduler().runTaskTimer(plugin, this::tick, 0L, 10L);
    }

    public void stop() {
        if (task != null) task.cancel();
    }

    private void tick() {
        for (Player player : Bukkit.getOnlinePlayers()) {
            PotionType slot1 = plugin.getSlotManager().getSlot1(player.getUniqueId());
            PotionType slot2 = plugin.getSlotManager().getSlot2(player.getUniqueId());

            // Always show both slot boxes (even if empty) once any potion is ever drunk
            // So we always render both if at least one slot is occupied
            if (slot1 == null && slot2 == null) continue;

            Component bar = Component.empty()
                    .append(buildSlot(player, slot1))
                    .append(Component.text("  ", NamedTextColor.DARK_GRAY))
                    .append(buildSlot(player, slot2));

            player.sendActionBar(bar);
        }
    }

    private Component buildSlot(Player player, PotionType type) {
        // Background always shown
        Component bg = Component.text(SLOT_BG)
                .style(Style.style().font(ICON_FONT).build());

        if (type == null) {
            return bg; // empty slot: just the dark box, no icon or text
        }

        IconInfo info = ICONS.getOrDefault(type, new IconInfo("?", NamedTextColor.WHITE));
        boolean onCooldown = plugin.getCooldownManager().isOnCooldown(player.getUniqueId(), type);
        long remaining = plugin.getCooldownManager().getRemainingSeconds(player.getUniqueId(), type);

        // NEG_SPACE moves cursor back so icon overlaps the slot background
        Component icon = Component.text(info.character())
                .style(Style.style().font(ICON_FONT).build())
                .color(info.color());

        Component status = onCooldown
                ? Component.text(" " + remaining + "s", NamedTextColor.YELLOW)
                : Component.text(" Ready", NamedTextColor.GREEN);

        return Component.text()
                .append(bg)
                .append(Component.text(NEG_SPACE))
                .append(icon)
                .append(status)
                .build();
    }
}
