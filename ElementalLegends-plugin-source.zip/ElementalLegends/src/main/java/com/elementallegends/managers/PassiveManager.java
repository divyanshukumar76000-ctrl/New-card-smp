package com.elementallegends.managers;

import com.elementallegends.items.ItemFactory;
import com.elementallegends.util.ItemKeys;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.plugin.Plugin;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;

/**
 * Applies passive effects every second based on the item a player is
 * holding or the armor they're wearing. Runs as a single repeating task
 * rather than per-item listeners to keep overhead low on large servers.
 */
public class PassiveManager {

    private final Plugin plugin;

    public PassiveManager(Plugin plugin) {
        this.plugin = plugin;
    }

    public void start() {
        new BukkitRunnable() {
            @Override
            public void run() {
                for (Player player : Bukkit.getOnlinePlayers()) {
                    applyHeldItemPassives(player);
                    applyArmorPassives(player);
                }
            }
        }.runTaskTimer(plugin, 0L, 20L); // every second
    }

    private void applyHeldItemPassives(Player player) {
        PlayerInventory inv = player.getInventory();
        ItemStack main = inv.getItemInMainHand();
        ItemKeys.ItemId id = ItemFactory.idOf(main);
        if (id == null) return;

        switch (id) {
            case FIRE_SWORD -> {
                player.setFireTicks(0);
                give(player, PotionEffectType.FIRE_RESISTANCE, 1);
            }
            case WATER_SWORD -> {
                give(player, PotionEffectType.WATER_BREATHING, 1);
                give(player, PotionEffectType.DOLPHINS_GRACE, 1);
                if (player.getEyeLocation().getBlock().isLiquid()) {
                    give(player, PotionEffectType.NIGHT_VISION, 1);
                }
                applyWaterWalking(player);
            }
            case THUNDER_SWORD -> {
                give(player, PotionEffectType.SPEED, 0);
                give(player, PotionEffectType.JUMP_BOOST, 0);
            }
            case VOID_MACE -> {
                give(player, PotionEffectType.STRENGTH, 1);
                give(player, PotionEffectType.RESISTANCE, 0);
                give(player, PotionEffectType.SLOW_FALLING, 0);
            }
            default -> {}
        }
    }

    private void applyArmorPassives(Player player) {
        PlayerInventory inv = player.getInventory();
        boolean fullVoidSet =
                ItemFactory.idOf(inv.getHelmet()) == ItemKeys.ItemId.VOID_HELMET &&
                ItemFactory.idOf(inv.getChestplate()) == ItemKeys.ItemId.VOID_CHESTPLATE &&
                ItemFactory.idOf(inv.getLeggings()) == ItemKeys.ItemId.VOID_LEGGINGS &&
                ItemFactory.idOf(inv.getBoots()) == ItemKeys.ItemId.VOID_BOOTS;

        if (!fullVoidSet) return;

        give(player, PotionEffectType.SPEED, 1);
        give(player, PotionEffectType.RESISTANCE, 0);
        give(player, PotionEffectType.REGENERATION, 0);
        give(player, PotionEffectType.NIGHT_VISION, 0);
        give(player, PotionEffectType.SLOW_FALLING, 0);
        player.setFireTicks(0);

        Location loc = player.getLocation();
        loc.getWorld().spawnParticle(Particle.PORTAL, loc.add(0, 1, 0), 3, 0.4, 0.6, 0.4, 0.01);
        if (Math.random() < 0.3) {
            loc.getWorld().spawnParticle(Particle.SMOKE, loc, 2, 0.3, 0.1, 0.3, 0.01);
        }
    }

    private void applyWaterWalking(Player player) {
        Location below = player.getLocation().clone().subtract(0, 1, 0);
        if (below.getBlock().getType() == org.bukkit.Material.WATER && player.getLocation().getBlock().getType() != org.bukkit.Material.WATER) {
            below.getWorld().spawnParticle(Particle.SPLASH, below, 3, 0.3, 0.05, 0.3);
        }
    }

    private void give(Player player, PotionEffectType type, int amplifier) {
        // Refresh just past the tick interval so the effect never visibly runs out.
        player.addPotionEffect(new PotionEffect(type, 40, amplifier, true, false));
    }
}
