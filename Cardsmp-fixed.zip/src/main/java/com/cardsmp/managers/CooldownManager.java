package com.cardsmp.managers;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class CooldownManager {

    private static final long COOLDOWN_MS = 30_000L;

    private final Map<UUID, Long> cooldowns = new HashMap<>();

    public boolean isOnCooldown(UUID playerUUID) {
        Long last = cooldowns.get(playerUUID);
        if (last == null) return false;
        return (System.currentTimeMillis() - last) < COOLDOWN_MS;
    }

    public long getRemainingSeconds(UUID playerUUID) {
        Long last = cooldowns.get(playerUUID);
        if (last == null) return 0;
        long remaining = COOLDOWN_MS - (System.currentTimeMillis() - last);
        return Math.max(0, (remaining + 999) / 1000);
    }

    public void setCooldown(UUID playerUUID) {
        cooldowns.put(playerUUID, System.currentTimeMillis());
    }
}